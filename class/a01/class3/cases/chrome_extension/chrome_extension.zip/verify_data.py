import json

def verify():
    with open("questions.json", "r", encoding="utf-8") as f:
        questions = json.load(f)
    
    errors = []
    
    # 1. 檢查題數
    if len(questions) != 50:
        errors.append(f"錯誤：題目總數為 {len(questions)}，預期應為 50。")
    
    # 2. 檢查每題的格式與內容
    for idx, q in enumerate(questions):
        q_id = q.get("id")
        # 檢查題號順序
        if q_id != idx + 1:
            errors.append(f"題號不符合順序：索引 {idx} 的題號為 {q_id}，預期為 {idx + 1}")
        
        # 檢查答案合法性
        ans = q.get("answer")
        if ans not in ["A", "B", "C", "D"]:
            errors.append(f"第 {q_id} 題：答案 '{ans}' 不合法，預期為 A, B, C, 或 D")
        
        # 檢查題目是否為空
        question_text = q.get("question", "").strip()
        if not question_text:
            errors.append(f"第 {q_id} 題：題目內容為空")
        
        # 檢查選項
        options = q.get("options", {})
        for opt_key in ["A", "B", "C", "D"]:
            opt_val = options.get(opt_key, "").strip()
            if not opt_val:
                errors.append(f"第 {q_id} 題：選項 ({opt_key}) 的內容為空")
                
    if errors:
        print("❌ 驗證失敗！發現以下錯誤：")
        for err in errors:
            print(f"- {err}")
        return False
    else:
        print("✅ 驗證成功！所有題目格式正確，共 50 題。")
        return True

if __name__ == "__main__":
    verify()
