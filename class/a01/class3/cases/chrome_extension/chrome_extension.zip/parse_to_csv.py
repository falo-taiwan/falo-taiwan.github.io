import re
import csv

def parse_txt_to_csv(raw_txt_path, csv_path):
    with open(raw_txt_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    questions = []
    current_q = None
    current_state = None  # 'question' or 'option'
    current_opt = None

    # 頁首頁尾與無用行判定
    def is_junk_line(line):
        stripped = line.strip()
        if not stripped:
            return True
        if stripped.startswith("--- PAGE"):
            return True
        if "115 年第一次 AI 應用規劃師" in stripped:
            return True
        if "第一科：人工智慧基礎概論" in stripped:
            return True
        if "考試日期：" in stripped:
            return True
        if re.search(r"第\s*\d+\s*頁，共\s*\d+\s*頁", stripped):
            return True
        if stripped == "答案 題目":
            return True
        return False

    # 題號與正確答案的 Regex 模式 (例如: D 1. 下列何者...)
    q_start_pat = re.compile(r"^([A-D])\s+(\d+)\.\s*(.*)$")
    
    # 選項的 Regex 模式 (例如: (A)選項內容)
    opt_start_pat = re.compile(r"^\(([A-D])\)\s*(.*)$")

    for line in lines:
        line_str = line.replace('\n', '').replace('\r', '')
        
        if is_junk_line(line_str):
            continue

        # 1. 檢查是否為新題目起點
        q_match = q_start_pat.match(line_str.strip())
        if q_match:
            if current_q:
                questions.append(current_q)
            
            ans = q_match.group(1)
            q_id = int(q_match.group(2))
            q_text = q_match.group(3).strip()
            
            current_q = {
                "id": q_id,
                "answer": ans,
                "question": q_text,
                "options": {
                    "A": "",
                    "B": "",
                    "C": "",
                    "D": ""
                }
            }
            current_state = 'question'
            continue

        # 2. 檢查是否為新選項起點
        opt_match = opt_start_pat.match(line_str.strip())
        if opt_match and current_q:
            opt_char = opt_match.group(1)
            opt_text = opt_match.group(2).strip()
            
            current_q["options"][opt_char] = opt_text
            current_state = 'option'
            current_opt = opt_char
            continue

        # 3. 若非題目或選項起點，則依當前狀態累加文字
        if current_q:
            if current_state == 'question':
                sep = " " if current_q["question"] and (current_q["question"][-1].isalnum() or line_str.strip() and line_str.strip()[0].isalnum()) else ""
                current_q["question"] += sep + line_str.strip()
            elif current_state == 'option' and current_opt:
                opt_str = current_q["options"][current_opt]
                sep = " " if opt_str and (opt_str[-1].isalnum() or line_str.strip() and line_str.strip()[0].isalnum()) else ""
                current_q["options"][current_opt] += sep + line_str.strip()

    # 儲存最後一題
    if current_q:
        questions.append(current_q)

    # 後處理：清理多餘的空格與標記（例如選項尾部的分號，以及報告指出的斷字排版瑕疵）
    replacements = {
        "變 化": "變化",
        "滿 溢度": "滿溢度",
        "規 劃": "規劃",
        "穩 定性": "穩定性",
        "Loss Functi on": "Loss Function",
        "比例一 致": "比例一致",
        "標準 化": "標準化",
        "Training  Data": "Training Data",
        "原 始數值": "原始數值",
        "數值格 式": "數值格式",
        "機率時， 資料同時": "機率時，資料同時",
        "也能 對未出現": "也能對未出現",
        "風 格草圖": "風格草圖",
        "V AE": "VAE",
        "外建置 一套": "外建置一套",
        "正 確": "正確",
        "一種 情境": "一種情境",
        "逐步朝 較佳績效收斂": "逐步朝較佳績效收斂",
        "測試資 料": "測試資料",
        "風格變 化": "風格變化",
        "模 型技術": "模型技術",
        "壓 力": "壓力",
        "不同 的狀態": "不同的狀態",
        "Real- time": "Real-time",
        "Inference） 」常依": "Inference）」常依",
        "偏 好": "偏好",
        "品質 差異": "品質差異",
        "行為表 現": "行為表現",
        "表示學習 訓練": "表示學習訓練",
        "部 分": "部分",
        "這種情 況": "這種情況",
        "天氣 等因素": "天氣等因素",
        "條 文": "條文",
        "影 像資料": "影像資料",
        "瑕疵 判定": "瑕疵判定",
        "特徵資 訊": "特徵資訊",
        "學習 類型": "學習類型",
        "資料 中": "資料中",
        "運算 成本": "運算成本",
        "速 度": "速度",
        "文件 時": "文件時",
        "舊 版內容": "舊版內容",
        "交 易金額": "交易金額",
        "最 適合的改 善策略": "最適合的改善策略",
        "V olume": "Volume"
    }

    def clean_text(text):
        if not text:
            return text
        # 1. 移除全形標點與符號前後的半形空格
        text = re.sub(r'\s*([，。；：！？（）「」『』《》、])\s*', r'\1', text)
        # 2. 特殊單字對照替換
        for target, replacement in replacements.items():
            text = text.replace(target, replacement)
        return text.strip()

    for q in questions:
        q["question"] = clean_text(q["question"])
        for opt in ["A", "B", "C", "D"]:
            opt_val = q["options"][opt].strip()
            if opt_val.endswith("；") or opt_val.endswith(";"):
                opt_val = opt_val[:-1].strip()
            q["options"][opt] = clean_text(opt_val)

    # 寫入成 CSV 檔案 (採用 utf-8-sig 以便 Excel 直接開啟中文不亂碼)
    with open(csv_path, 'w', encoding='utf-8-sig', newline='') as f:
        writer = csv.writer(f)
        # 寫入標頭
        writer.writerow(['id', 'question', 'optionA', 'optionB', 'optionC', 'optionD', 'answer'])
        
        for q in questions:
            writer.writerow([
                q['id'],
                q['question'],
                q['options']['A'],
                q['options']['B'],
                q['options']['C'],
                q['options']['D'],
                q['answer']
            ])

    print(f"成功將 PDF 文字轉為 CSV 題庫！共 {len(questions)} 題。")
    print(f"CSV 檔案已儲存至: {csv_path}")

if __name__ == "__main__":
    parse_txt_to_csv("raw_text.txt", "questions.csv")
