import csv
import json

def convert_csv_to_js(csv_path, js_path, json_path):
    questions = []
    
    with open(csv_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            questions.append({
                "id": int(row["id"]),
                "answer": row["answer"].strip(),
                "question": row["question"].strip(),
                "options": {
                    "A": row["optionA"].strip(),
                    "B": row["optionB"].strip(),
                    "C": row["optionC"].strip(),
                    "D": row["optionD"].strip()
                }
            })
            
    # 輸出為 JS 檔案 (定義全域常數 QUESTIONS)
    with open(js_path, 'w', encoding='utf-8') as f:
        f.write("// 115年第一次初級AI應用規劃師_第一科_人工智慧基礎概論_公告試題 (由 CSV 轉譯)\n")
        f.write("const QUESTIONS = ")
        json.dump(questions, f, ensure_ascii=False, indent=2)
        f.write(";\n")
        
    # 輸出為 JSON 檔案
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(questions, f, ensure_ascii=False, indent=2)
        
    print(f"CSV 轉 JS/JSON 完成！共轉換了 {len(questions)} 題。")
    print(f"JS 檔案已儲存至: {js_path}")
    print(f"JSON 檔案已儲存至: {json_path}")

if __name__ == "__main__":
    convert_csv_to_js("questions.csv", "questions.js", "questions.json")
