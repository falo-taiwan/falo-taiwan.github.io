import pypdf

def extract_pdf_text(pdf_path, txt_path):
    reader = pypdf.PdfReader(pdf_path)
    full_text = []
    for i, page in enumerate(reader.pages):
        text = page.extract_text()
        full_text.append(f"--- PAGE {i+1} ---")
        full_text.append(text)
    
    with open(txt_path, "w", encoding="utf-8") as f:
        f.write("\n".join(full_text))

if __name__ == "__main__":
    pdf_file = "115年第一次初級AI應用規劃師_第一科_人工智慧基礎概論_公告試題_20260410164304.pdf"
    txt_file = "raw_text.txt"
    extract_pdf_text(pdf_file, txt_file)
    print("PDF text extracted to raw_text.txt")
