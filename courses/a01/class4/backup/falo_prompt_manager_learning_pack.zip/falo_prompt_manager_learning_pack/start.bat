@echo off
chcp 65001 > nul
title FALO Prompt Manager 啟動器
echo ========================================================================
echo 🌌 FALO Prompt Manager - PWA 本地啟動伺服器 (Windows)
echo ========================================================================
echo.
echo 正在檢測系統 Python 環境...
echo.

python --version >nul 2>&1
if %errorlevel% equ 0 (
    echo [OK] 檢測到 Python 安裝！
    echo 正在背景開啟預設瀏覽器至 http://localhost:8000 ...
    start http://localhost:8000
    echo.
    echo ========================================================================
    echo 正在啟動 Python 本地伺服器於 Port 8000...
    echo.
    echo [提示] 請保持此黑色視窗開啟，不要關閉。
    echo [提示] 當您不需要使用時，直接關閉此視窗或在視窗內按下 Ctrl + C 即可結束。
    echo ========================================================================
    echo.
    python -m http.server 8000
) else (
    echo [!] 未檢測到 Python。
    echo 系統將直接使用 file:// 協議直接雙擊打開 index.html 檔案。
    echo.
    echo [注意] 此模式不支援 PWA 安裝按鈕與離線快取，但複製/編輯/變數預覽均能 100%% 正常運作。
    echo.
    pause
    start index.html
)
