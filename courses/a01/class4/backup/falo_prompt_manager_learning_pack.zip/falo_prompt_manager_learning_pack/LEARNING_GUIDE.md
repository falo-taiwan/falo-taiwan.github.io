# FALO Prompt Manager 學習導讀指南 (LEARNING_GUIDE.md)

本指南旨在幫助**人類學員**與 **AI Agent（智慧代理）**理解 FALO Prompt Manager 專案的核心架構、設計模式與技術實作，特別是 **「PWA 本地主中心 + Chrome 衛星外掛」** 的雙向協作設計，以便進行模仿、重製與二次開發。

---

## 🌌 1. 專案定位與「地端優先」哲學

在 FALO 產品生態系中，本專案屬於 **FALO Prompt（Skill 技能層）**：
* **FALO Book (Knowledge)**：負責知識傳遞，讓使用者「理解」概念。
* **FALO Prompt (Skill)**：指令資產管理層，讓使用者「快速套用與共創」。
* **FALO Runtime (Execution)**：執行層，讓任務真正自動化落地。

FALO Prompt Manager 的核心設計哲學為：
> **「殼公開，卡分級；離線先匯入，線上接 GAS。」**

它是一個 **Local-first（地端優先）** 的 PWA。所有資料的編輯與儲存預設均在瀏覽器本地的 IndexedDB / LocalStorage 完成，沒有敏感資料上傳至第三方伺服器的隱憂，確保商業隱私與資料 100% 不落地。

---

## 🛰️ 2. 為什麼需要「衛星 Chrome 外掛」？（核心設計模式）

對於大多數網頁型應用程式（Web App / PWA）來說，**「跨網域安全沙盒限制」** 是一個無法避開的痛點：

### 2.1 網頁型 App 的安全困境
網頁（如 `https://falo-taiwan.github.io/` 或本地的 `file:///`）受到瀏覽器**同源政策 (Same-Origin Policy)** 與 **跨來源資源共用 (CORS)** 的嚴格限制。
* 網頁 App **無法**直接讀寫其他分頁（如 ChatGPT、Gemini、Claude、或企業內部的 ERP 系統）的內容。
* 網頁 App **無法**繞過 CORS 去抓取某些沒有開放跨域存取的外部 API 資源。

### 2.2 「PWA 主中心 + 衛星外掛」的協作模式
為了打破這個限制，本專案採用了**「地端主中心 (Command Center) ＋ 衛星外掛 (Satellite effector)」** 的協作架構：

1. **主網頁 PWA（大腦/資料庫）**：
   * 負責複雜的 UI 操作、分類管理、Prompt 卡片編修、Excel/CSV 檔案匯入匯出。
   * 負責儲存與維護所有的指令範本與變數對照表（大本營）。
2. **Chrome 外掛（雙手/執行器）**：
   * 利用 Chrome 擴充功能的高級特權（Content Scripts、Side Panel API），突破同源政策限制。
   * **功能**：外掛能直接偵測使用者當前開啟的網頁是否為 ChatGPT 或 Gemini，並自動將 PWA 代入變數後的 Prompt 填入該網頁的輸入框。
   * **同步**：透過本地通訊（雙向握手），一鍵拉取（Pull）或推送（Push）目前 PWA 網頁上的最新指令庫，免除檔案導出與導入的繁瑣步驟。

### 2.3 如何推廣至其他網頁型 App？
任何網頁型 App（例如：密碼管理器、表單自動填寫器、翻譯助手、行銷文案產生器）都可以模仿此設計：
* **解耦資料與操作**：將主要資料庫與繁重 UI 留在 Web App 中（便於跨平台、免發布審查）；
* **外掛作為輕量通道**：外掛只負責讀取當前標籤頁 DOM 與網頁注入，並定時發送訊息與 Web App 同步。這能讓外掛體積極小化，極易通過 Chrome 線上商店的安全審核。

---

## 📂 3. 目錄與檔案結構說明

解壓本學習包後，您的目錄結構如下：

```text
falo_prompt_manager_learning_pack/
├── index.html                  # PWA 主網頁本體（核心 UI 與 JavaScript 互動狀態管理邏輯）
├── manifest.webmanifest        # PWA 設定檔（定義應用程式名稱、啟動路徑、圖示與主題色彩）
├── service-worker.js           # 本地離線快取的 Service Worker，控制離線加載與快取規則
├── icon.svg                    # FALO Prompt Manager 的向量 SVG 標誌
├── xlsx.full.min.js            # SheetJS 函式庫，負責地端 PWA 對 CSV 與 Excel 的本地解析
├── falo_prompt_satellite_v2.2.zip # 封裝好的 Chrome 衛星外掛資源包（安裝時解壓載入即可）
├── start.bat                   # Windows 批次腳本，一鍵啟動 Python 本地伺服器 (http.server)
├── LEARNING_GUIDE.md           # 本 Markdown 導讀指南
├── LEARNING_GUIDE.html         # 網頁版高質感導讀指南（針對人類補充讀者提示區與常見問答）
├── README.md                   # 專案的基本介紹與定位說明
├── HANDOFF.md                  # 設計理念傳承與接手說明文件
└── examples/                   # 學習與測試用的標準資料夾
    ├── notebooklm_shared_brains_prompts.csv # 範例 CSV 資料庫（可用 PWA 的匯入功能加載）
    └── prompt_database_template.json        # 範例 JSON 資料庫
```

---

## 🛠️ 4. 核心技術實作剖析

### 4.1 PWA 離線與 Service Worker 策略
為了支援離線使用，`service-worker.js` 會快取應用程式的殼層（Shell），包含 HTML、JS 與 SVG。
* **SW 版本更新機制**：每當發布新版本時，更新 `service-worker.js` 中的 `CACHE_NAME` 版本號，瀏覽器會自動在背景下載新版，並在下次開啟時替換。
* **排除快取規則**：外掛包 `.zip` 與大檔案會被排除在快取外，確保直接從網路下載，減少本機儲存負擔。

### 4.2 雙向身分握手與心跳機制 (PWA ↔ Chrome Extension)
為了讓「地端網頁」能與「側邊欄外掛」即時同步，專案實作了**雙向握手機制**：
* PWA 主頁面會宣告一個全域屬性 `window.__FALO_PWA_METADATA__` 標記自身身分。
* Chrome 外掛會定時發送 `PING` 訊息，若偵測到該標記，雙方即建立連線並更新「🛰️ 衛星外掛：已連線」狀態。

### 4.3 模式切換與欄位保護 (精簡/完整模式)
* **精簡模式 (Compact Mode)**：隱藏用途說明、人工檢查點等行政次要欄位，專注於 Prompt 複製。
* **完整模式 (Full Mode)**：展示全部欄位，方便管理者與講師編修。
* **欄位保護**：當使用者在「精簡模式」下編輯卡片時，隱藏欄位的值會完整保留在內建資料庫中，避免覆寫遺失。

### 4.4 語音聽寫與影像辨識入口
* **Web Speech API**：實作免伺服器的瀏覽器語音轉文字功能，聽寫結果寫入 `[Voice_Text]` 變數。
* **OCR 入口**：對接獨立的 OCR 工作台，支援影像與截圖結構化為 Markdown，回填至變數。

---

## 🤖 5. AI Agent 模仿與重製指引

如果您是 AI Agent，想要重製或修改此專案，請注意以下實作細節：

### 5.1 HTML 結構設計
* 採用三欄式 Grid 佈局：
  * 左欄（`.sidebar`）：分類列表與分類管理。
  * 中欄（`.main`）：統計指標面板、卡片列表與 Prompt 編輯工作台。
  * 右欄（`.inspector`）：Voice 語音捕捉、OCR 入口、置頂變數控制面板。
* **關鍵 CSS 規則**：RWD 斷點需設為 `1280px`。當寬度低於 `1280px` 時，右欄自動折疊至最下方，以防止中間區域的變數卡片與右欄發生溢出重疊。

### 5.2 JavaScript 狀態管理
* 核心狀態物件包括 `database` (分類與卡片陣列) 與 `variables` (全域變數對照表)。
* **資料同步**：每次修改狀態後，需同時調用 `saveState()` 將其寫入 LocalStorage，並調用 `render()` 觸發 UI 重繪。
* **變數動態提取**：Prompt 內容中符合 `[變數名]` 或 `{{變數名}}` 的部分，需透過正則表達式 `/(\[([A-Za-z0-9_]+)\]|\{\{([A-Za-z0-9_]+)\}\})/g` 動態擷取，並自動在右側變數面板生成對應的輸入框。
