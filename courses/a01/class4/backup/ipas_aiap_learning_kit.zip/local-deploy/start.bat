@echo off
:: 設定編碼為 UTF-8，以正常顯示中文
chcp 65001 >nul
title iPAS AIAP 本地伺服器啟動器 (Falo x Force Cheng)

echo =======================================================
echo 🚀 正在準備啟動 iPAS AIAP 本地伺服器...
echo =======================================================
echo.

:: 檢查 Python 是否已安裝並加入環境變數
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ 錯誤：找不到 Python 執行檔！
    echo.
    echo 💡 解決方法：
    echo 1. 請至 Python 官方網站下載安裝包：https://www.python.org/downloads/
    echo 2. 安裝時「務必勾選」下面這個選項：
    echo    [v] Add python.exe to PATH (將 Python 加入環境變數)
    echo 3. 安裝完成後，請重新雙擊執行此 start.bat 檔案。
    echo.
    pause
    exit /b 1
)

:: 執行 Python 啟動器
python run_local.py

if %errorlevel% neq 0 (
    echo.
    echo ❌ 伺服器異常終止。
    pause
)
