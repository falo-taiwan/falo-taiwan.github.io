#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Falo x Force Cheng iPAS AIAP 本地伺服器啟動器 (run_local.py)
用途：在本地啟動輕量伺服器，自動開啟瀏覽器，解決本地 file:// 協議帶來的 CORS 限制。
"""

import http.server
import socketserver
import webbrowser
import threading
import time
import sys

# 嘗試尋找可用連接埠
START_PORT = 8001
MAX_PORT_ATTEMPTS = 10

def find_available_port(start_port):
    for port in range(start_port, start_port + MAX_PORT_ATTEMPTS):
        try:
            # 測試綁定
            with socketserver.TCPServer(("", port), None) as s:
                return port
        except OSError:
            continue
    return None

class QuietHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    """靜音請求日誌，保持終端機乾淨"""
    def log_message(self, format, *args):
        pass

def start_server(port):
    Handler = QuietHTTPRequestHandler
    # 允許地址重用，防止 Port Close 延遲導致的 Address already in use
    socketserver.TCPServer.allow_reuse_address = True
    try:
        with socketserver.TCPServer(("", port), Handler) as httpd:
            print(f"\n=======================================================")
            print(f"🚀 FALO Taiwan × iPAS AIAP 本地服務已啟動！")
            print(f"🔗 模擬器網址: http://localhost:{port}/practice-swiper.html")
            print(f"按 Ctrl+C 可以隨時關閉伺服器。")
            print(f"=======================================================\n")
            httpd.serve_forever()
    except Exception as e:
        print(f"❌ 啟動伺服器失敗: {e}", file=sys.stderr)

def main():
    port = find_available_port(START_PORT)
    if not port:
        print(f"❌ 錯誤：無法在連接埠 {START_PORT} - {START_PORT + MAX_PORT_ATTEMPTS} 找到可用連接埠，請關閉其他佔用程式。", file=sys.stderr)
        sys.exit(1)

    # 於背景線程啟動伺服器
    server_thread = threading.Thread(target=start_server, args=(port,))
    server_thread.daemon = True
    server_thread.start()

    # 稍微等待伺服器就緒後開啟瀏覽器
    time.sleep(0.5)
    
    url = f"http://localhost:{port}/practice-swiper.html"
    print(f"🌐 正在自動開啟瀏覽器載入: {url}")
    webbrowser.open(url)

    # 保持主線程運行以響應 Ctrl+C
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n👋 已接收到關閉訊號，伺服器關閉，祝學習順利！")
        sys.exit(0)

if __name__ == "__main__":
    main()
