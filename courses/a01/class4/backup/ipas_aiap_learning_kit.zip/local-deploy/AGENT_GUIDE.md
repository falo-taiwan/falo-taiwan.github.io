# iPAS AIAP Swiper Simulator - AI Agent Integration & Developer Manual (v1.01)

> [!NOTE]
> **SYSTEM CONTEXT FOR AI DEVELOPER AGENTS**
> This file is a machine-readable technical reference manual. If you are an AI Coding Agent assisting the student, ingest this file to understand the system architecture, code variables, data contracts, and customization rules of this static HTML workspace.

---

## 📂 Codebase Directory Map

```text
local-deploy/
├── practice-swiper.html  # Main Simulator Application (Single Page App: HTML, CSS, JS)
├── questions.csv         # Decoupled Question Bank (Target for CSV schema modification)
├── run_local.py          # Python 3 Local Server Launcher (Bypasses browser file:// CORS sandbox)
├── start.bat             # Windows OS Launcher Batch Script (Invokes python run_local.py)
├── AGENT_GUIDE.md        # [THIS FILE] AI Agent Ingestion Guide (System Specs & Contracts)
└── AGENT_GUIDE.html      # Human-Readable Study Guide (Pedagogical Explanations of CORS, 3-Tier Loader)
```

---

## ⚙️ Core System Configuration & Mappings

Inside `practice-swiper.html`, the system uses the following global variables and configurations. Do not modify these names unless instructed.

### 1. API Endpoint and Pricing Configurations
*   `GOOGLE_SHEET_ID`: Represents the source Google Sheet ID for question bank replication.
    `const GOOGLE_SHEET_ID = "1F3XY1WblxeXU62BEJelSkEsyVRdeW-ogrpa5T1iS1jk";`
*   `QUESTIONS_GID`: GID representing the specific sheet tab within the spreadsheet.
    `const QUESTIONS_GID = "109381915";`
*   `CSV_URL`: Composed Google Sheet export URL.
*   `MODEL_RATES`: Dictionary storing the pricing rates (USD per 1,000,000 tokens) for input and output.
    ```javascript
     const MODEL_RATES = {
       'gemini-3.1-flash-lite': { input: 0.25, output: 1.50 },
       'gemini-3.1-pro': { input: 2.00, output: 12.00 },
       'gemini-2.5-flash-lite': { input: 0.10, output: 0.40 },
       'gemini-2.5-flash': { input: 0.30, output: 2.50 },
       'gemini-3.5-flash': { input: 1.50, output: 9.00 }
     };
    ```

### 2. 3-Tier Question Loader Architecture
The function `loadQuestionBank()` implements a fallback chain to bypass CORS security policies:
1.  **Tier 1**: Fetch local relative `./questions.csv` using `Papa.parse()`.
    *   *If success*: calls `processCsvData()`.
    *   *If error (e.g. CORS block under file://)*: catches error and triggers Tier 2.
2.  **Tier 2**: Fetch remote `CSV_URL` from Google Sheet.
    *   *If success*: calls `processCsvData()`.
    *   *If error (e.g. offline)*: catches error and triggers Tier 3.
3.  **Tier 3**: Fallback directly to the internal hardcoded array `fallbackQuestions`.

---

## 📊 Data Schema Contracts

When reading/writing data, the AI Agent must strictly follow these JSON structures.

### 1. Question Object Schema (parsed from CSV)
```json
{
  "id": "A1_114_01",
  "subject": "人工智慧基礎概論",
  "filename": "114年第四次初階人工智慧基礎概論",
  "qno": 1,
  "question": "關於生成式人工智慧（Generative AI）的描述，下列何者「錯誤」？",
  "options": [
    "主要是透過學習大量既有數據的分布規則，來生成全新的原創內容",
    "大型語言模型（LLM）如 GPT 屬於生成式 AI 的典型應用",
    "生成式 AI 只能處理和生成純文字內容，無法生成圖像或音訊",
    "在使用生成式 AI 時，可能會產生「幻覺（Hallucination）」即生成虛假不實的內容"
  ],
  "answer": "3"
}
```

### 2. Session Object Schema (Saved to `localStorage` key `ipas_benchmark_history`)
```json
{
  "id": 1718957263000,
  "timestamp": "2026/06/25 12:00:00",
  "model": "gemini-3.1-flash-lite",
  "mode": "sequential",
  "interval": "3",
  "accuracy": "80% (4/5)",
  "accuracyPct": 80,
  "avgSpeed": "2.45",
  "totalTokens": 6450,
  "totalCost": "0.05432",
  "note": "這是測試備註文字",
  "results": [
    {
      "round": 1,
      "qId": "A1_114_01",
      "aiAnswer": "3",
      "stdAnswer": "3",
      "isCorrect": true,
      "status": "success",
      "seconds": 2.1,
      "inputTokens": 1024,
      "outputTokens": 256,
      "totalTokens": 1280,
      "ntdCost": 0.0108
    }
  ]
}
```

---

## 🎨 UI Customization & Watermark Specifications

*   **CSS Theme Customization**: Modify CSS variables under `:root` in `practice-swiper.html` to adjust the layout colors.
*   **Screenshots Watermark (隱藏浮水印)**:
    *   Implemented via `body::before` pseudo-element.
    *   **Text content**: `Falo x Force Cheng v1.01 2026/06/25`.
    *   **Style Specification**: Fixed, full-screen background repeating SVG, `z-index: 99999`, `pointer-events: none` (to allow normal click interactions), opacity of text set to `0.02` for subtle screenshot copyright verification.
    ```css
    body::before {
      content: "";
      position: fixed;
      top: 0; left: 0; width: 100%; height: 100%;
      pointer-events: none;
      z-index: 99999;
      background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' ...><text opacity='0.02' transform='rotate(-28 160 110)'>Falo x Force Cheng v1.01 2026/06/25</text></svg>");
      background-repeat: repeat;
    }
    ```

---

## 🎯 Developer Recipes for AI Agents

If the user gives you a task, locate the corresponding function hooks:

1.  **To Modify Billing Calculations**:
    Locate `MODEL_RATES` and edit the input/output cost multipliers. The formula converts USD to NTD using a 30x multiplier: `ntdCost = (inputTokens * rate.input + outputTokens * rate.output) * 30 / 1000000`.
2.  **To Sync Custom Remarks**:
    The text-area `oninput` calls `updateActiveSessionNote(newNote)`. This modifies `activeSessionData.note` and finds the index of the session in `localStorage.getItem('ipas_benchmark_history')` to save it in-place and call `renderHistoryList()`.
3.  **To Change Question Loading Path**:
    Locate the `loadQuestionBank()` and replace `Papa.parse("./questions.csv", ...)` with your target path if you want to support multiple CSV file sets.
