# 微信視頻號（WeChat Channels）影片串流擷取與投影片轉換：技術分析與解決方案總結

本文件彙整了針對微信視頻號預覽網址（`channels.weixin.qq.com/finder-preview`）進行影片串流擷取、安全機制繞過以及投影片自動化萃取轉換的技術細節、實驗數據與系統架構，旨在提供給其他 AI 模型進行深度分析、評估與後續開發。

---

## 一、 微信視頻號網頁端安全機制與技術發現

我們針對目標網址進行了自動化網頁渲染（Playwright Headless）與網路流量攔截（Network Interception），得出以下核心技術結論：

### 1. 串流保護機制：伺服器端憑證隔離
*   **現象**：未登入的標準瀏覽器開啟連結後，會立即彈出「可掃碼前往微信觀看此內容」的 QR Code 遮罩。
*   **DOM 結構分析**：
    *   關閉遮罩後，影片播放區域（`.video-container`）在 DOM 中並非 `<video>` 標籤，而是一個 **`<img>` 標籤**。
    *   該圖片網址指向：`https://finder.video.qq.com/...&picformat=200`（這是視訊的封面縮圖，並非串流）。
    *   當嘗試點擊播放（`.play-button`）時，網頁 JavaScript 會偵測運行環境。若未通過微信內部授權，將**直接攔截播放請求**並重新彈出 QR Code，自始至終**不會生成 `<video>` 標籤**，亦不會向伺服器發起視訊檔案請求。
*   **API 攔截數據（關鍵證據）**：
    *   網頁初始化時會向伺服器發送 `POST /finder-preview/api/feed/get_feed_info` 獲取媒體元數據。
    *   **JSON 響應結果**（詳見本地備份：`scratch/feed_info.json`）：
        *   `data.feedInfo` 結構中**僅包含 `coverUrl`（封面圖）**，完全沒有任何視訊串流網址（如 MP4、M3U8 等欄位）。
    *   **技術結論**：在未登入或非微信客戶端環境下，微信伺服器在 API 層面就進行了物理隔離，**根本不向客戶端發送視訊網址**。因此，純網頁端無頭爬蟲（Web Scraper）在不具備憑證時，在技術上是無法直接抓取到影片串流的。

### 2. 跨來源資源共享限制（CORS）
*   微信視頻號網頁網域為 `channels.weixin.qq.com`，而視訊與媒體伺服器網域為 `*.video.qq.com`。
*   即使瀏覽器成功播放影片，若要在網頁端透過 Canvas 進行影格擷取（`ctx.drawImage`），會因為跨來源限制導致 Canvas 遭受污染（Tainted Canvas），從而無法透過 `canvas.toDataURL()` 導出圖片，除非視訊源帶有 CORS 允許標頭或使用特定的瀏覽器外掛 API。

---

## 二、 目前已實作之解決方案

為打通「影片獲取 ➔ 投影片精確擷取 ➔ PDF/ZIP 導出」的完整工作流，目前專案已實作以下模組：

### 1. 本地免 CORS 限制的「網頁版影格捕捉與轉換器」
*   **程式路徑**：`capturer_tool.html`
*   **架構與技術特色**：
    *   **本地拖曳加載**：支援用戶直接將本地 MP4 影片（如透過嗅探工具下載的檔案）拖入網頁。由於使用 `URL.createObjectURL(file)` 進行本地加載，影片數據不經過網絡，**完全免除瀏覽器的 CORS 跨網域安全限制**，可進行 100% 高解析度 Canvas 影格擷取。
    *   **精確控制與快捷鍵**：支援精確至 0.1 秒的微調（`[` 與 `]` 鍵），以及一鍵擷取（`C` 鍵或 `Enter`）。
    *   **智慧型自動投影片偵測（Auto-Detect）**：
        *   採用前端輕量級像素對比演算法。當影片播放時，每秒在後台將影格繪製於 $32 \times 18$ 的極低解析度隱藏畫布上。
        *   計算相鄰影格的 RGB 均值變動率：
            $$\text{Difference} = \frac{\sum |R_t - R_{t-1}| + |G_t - G_{t-1}| + |B_t - B_{t-1}|}{3 \times \text{Width} \times \text{Height} \times 255} \times 100\%$$
        *   當變動率大於設定閾值（預設 15%）時，判定為投影片切換，自動觸發擷取。
    *   **多格式導出**：整合 `jsPDF` 與 `JSZip` CDN 庫，實現純客戶端生成 PDF 簡報與打包下載 ZIP 圖片檔。

### 2. Chrome 開發者外掛升級
*   **程式路徑**：`chrome-extension/`
*   **更新細節**：
    *   修改 `manifest.json`，將 `https://channels.weixin.qq.com/*` 加入 `host_permissions` 及 `content_scripts.matches`。
    *   **運作邏輯**：當用戶在 Chrome 中掃碼授權影片播放後，外掛可直接在網頁側邊欄（Side Panel）與頁面中的 `<video>` 標籤連線，控制播放進度並擷取影格。
    *   *註：若遇到 CORS 限制 Canvas 導出，可改用外掛後台的 `chrome.tabs.captureVisibleTab` 進行視窗截圖繞過。*

### 3. 開源嗅探工具本地備份（WechatVideoSniffer）
*   **備份路徑**：`backup/`
*   **備份檔案**：
    *   `WechatVideoSniffer_2.6.zip`（執行檔，採用系統代理 FiddlerCore 原理，監聽電腦版微信的網路流量，抓取已授權的 `finder.video.qq.com` 視訊直鏈）。
    *   `WechatVideoSniffer2.0_master_source.zip`（2.0 升級版完整源碼，支援直播回放批量下載及任務恢復）。
*   **文檔說明**：`backup/README.md` 及 `backup/report.html`。

---

## 三、 進階自動化架構設計（後續開發方向）

若要實現「全自動化」的大批量微信視頻號影片抓取，避免人工掃碼授權，建議採用以下 **Android 模擬器 + 抓包代理** 的技術架構：

```mermaid
graph TD
    A[微信視頻號連結] --> B[ADB 自動化控制指令碼]
    B --> C[Android 模擬器 - 登入微信]
    C --> D[微信內部瀏覽器播放影片]
    D -->|自帶加密憑證發起請求| E[系統網路代理: mitmproxy / Charles]
    E -->|攔截解密 HTTPS 流量| F[過濾 finder.video.qq.com]
    F -->|提取含憑證之視訊直鏈| G[Python 下載器]
    G -->|下載 MP4 檔案| H[Video to PPT 後端 app.py]
    H -->|OpenCV 投影片萃取| I[生成高畫質 PDF / PPTX]
```

### 關鍵技術挑戰與解決方案：
1.  **HTTPS 解密與憑證寫入**：
    *   Android 7.0+ 以上不再信任用戶自建證書。需使用 **Root 版模擬器**（如 Genymotion 或 Magisk 修補版），將代理工具的 CA 憑證寫入 `/system/etc/security/cacerts/` 目錄。
2.  **SSL Pinning（證書綁定）繞過**：
    *   微信可能會對特定域名進行證書綁定鎖定。需使用 **Frida** 注入動態腳本，或安裝 **LSPosed (Xposed) + JustTrustMe** 模塊，強行繞過微信的證書校驗。
3.  **ADB 進程控制**：
    *   使用 Python 的 `ppadb` 或 `uiautomator2` 庫，編寫腳本自動將複製的連結發送給模擬器中的「文件傳輸助手」，並模擬點擊播放，實現無人值守批量抓取。

---

## 四、 現行實用操作工作流（手機到電腦的橋樑）

目前最穩健、無需複雜逆向配置的日常操作流如下：

```
[手機微信端觀看影片]
       │
       ▼ (點擊分享 ➔ 複製連結)
[發送至電腦端微信]
       │
       ▼
[啟動 WechatVideoSniffer] ➔ [在電腦版微信點開播放]
       │
       ▼ (工具自動偵測並下載)
[獲取高清本地 MP4 影片]
       │
       ▼ (拖曳至本地網頁工具)
[capturer_tool.html] ➔ [自動影格偵測 + 導出高畫質 PDF]
```

本技術總結文件提供了微信視頻號在安全防禦、流量攔截、跨域處理及自動化轉換上的完整拼圖，可直接提供給其他人工智慧模型作為上下文背景，進行系統架構規劃與代碼編寫。
