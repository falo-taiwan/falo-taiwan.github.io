import os
import logging
import cv2
import numpy as np

def dhash(image: np.ndarray, hash_size: int = 8) -> int:
    """
    計算影像的差值雜湊值 (Difference Hash, dHash)。
    適用於檢測重複或高度相似的投影片。
    
    Args:
        image: BGR 格式的影像 (numpy 陣列)。
        hash_size: 雜湊大小，預設為 8 (產生 8x8 = 64 位元雜湊)。
        
    Returns:
        int: 64 位元整數代表的雜湊值。
    """
    # 轉為灰階
    if len(image.shape) == 3:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    else:
        gray = image

    # 縮放到 (width = hash_size + 1, height = hash_size)
    # 使用 INTER_AREA 內插以在縮小時保持文字邊緣清晰
    resized = cv2.resize(gray, (hash_size + 1, hash_size), interpolation=cv2.INTER_AREA)

    # 比較水平相鄰像素的亮度
    # resized[:, 1:] 是右側像素，resized[:, :-1] 是左側像素
    diff = resized[:, 1:] > resized[:, :-1]

    # 將布林陣列轉為一個整數
    hash_val = 0
    for i, bit in enumerate(diff.flatten()):
        if bit:
            hash_val |= (1 << i)
            
    return hash_val

def hamming_distance(hash1: int, hash2: int) -> int:
    """
    計算兩個 64 位元整數雜湊的漢明距離 (Hamming Distance)。
    漢明距離代表不同位元的數量，數值越小代表圖像越相似。
    """
    return bin(hash1 ^ hash2).count('1')

def format_timestamp(seconds: float) -> str:
    """
    將秒數轉換為 HH:MM:SS 的格式。
    
    Args:
        seconds: 影片時間秒數 (float)。
        
    Returns:
        str: 格式化後的時間戳，例如 "00:01:32"。
    """
    total_seconds = int(round(seconds))
    mins, secs = divmod(total_seconds, 60)
    hours, mins = divmod(mins, 60)
    return f"{hours:02d}:{mins:02d}:{secs:02d}"

def setup_logger(output_dir: str) -> logging.Logger:
    """
    設定雙向日誌輸出：同時輸出至終端機控制台以及 `output_dir/logs/extractor.log`。
    
    Args:
        output_dir: 輸出資料夾路徑。
        
    Returns:
        logging.Logger: 設定完成的日誌記錄器。
    """
    log_dir = os.path.join(output_dir, "logs")
    os.makedirs(log_dir, exist_ok=True)
    log_file_path = os.path.join(log_dir, "extractor.log")
    
    logger = logging.getLogger("VideoSlideExtractor")
    logger.setLevel(logging.INFO)
    
    # 避免重複添加 Handler (在多次呼叫此函式時)
    if logger.hasHandlers():
        logger.handlers.clear()
        
    # 定義日誌格式
    formatter = logging.Formatter(
        '[%(asctime)s] [%(levelname)s] %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # 終端機 Handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # 檔案 Handler
    file_handler = logging.FileHandler(log_file_path, encoding='utf-8')
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    
    return logger
