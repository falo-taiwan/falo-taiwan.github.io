import os
import sys
# 確保優先加載目前工作目錄的模組，防範與第三方套件名稱衝突
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

import time
import shutil
import threading
import logging
from flask import Flask, jsonify, request, send_from_directory, send_file

from extractor import VideoSlideExtractor, enhance_image
from utils import setup_logger

# 調整 Flask 開發日誌級別，避免日誌刷屏影響觀察
cli = sys.modules['flask.cli']
cli.show_server_banner = lambda *x: None
logging.getLogger('werkzeug').setLevel(logging.ERROR)

app = Flask(__name__)

# 全域狀態控制
active_extractor = None
extractor_thread = None
extractor_status = "idle"  # idle, running, completed, error
start_time = None
active_video_path = ""
active_output_dir = "output"

@app.route('/')
def index():
    """
    提供前端控制面板首頁。
    """
    # 預設從目前工作目錄載入 index.html
    return send_from_directory(os.getcwd(), "index.html")

@app.route('/output/<path:filename>')
def serve_output(filename):
    """
    動態映射輸出資料夾，讓前端可直接讀取 slide_xxx.png 與 preview_frame.jpg。
    """
    # 關閉瀏覽器快取，以防即時預覽影格和投影片讀到舊快取
    # 使用 output 根目錄以支援包含時間戳子目錄路徑的檔案服務
    response = send_from_directory(os.path.abspath("output"), filename)
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
    return response

@app.route('/api/analyze_video', methods=['POST'])
def analyze_video():
    """
    快速分析影片規格與畫質，YouTube 不下載，本地快速 Open/Release。
    """
    data = request.get_json() or {}
    video_path = data.get("video_path", "").strip()
    
    if not video_path:
        return jsonify({"error": "請提供影片路徑或 YouTube 網址！"}), 400
        
    is_youtube = ("youtube.com" in video_path or "youtu.be" in video_path or video_path.startswith("http"))
    
    try:
        if is_youtube:
            import yt_dlp
            ydl_opts = {
                'extractor_args': {
                    'youtube': {
                        'player_client': ['android', 'mweb']
                    }
                },
                'quiet': True,
                'no_warnings': True
            }
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(video_path, download=False)
                title = info.get('title', 'YouTube Video')
                duration = info.get('duration', 0)
                
                # 計算可用的畫質高度
                formats = info.get('formats', [])
                heights = set()
                for f in formats:
                    h = f.get('height')
                    if h and h in [360, 480, 720, 1080, 1440, 2160]:
                        heights.add(h)
                
                # 格式化時長
                from utils import format_timestamp
                duration_str = format_timestamp(duration) if duration else "未知長度"
                
                return jsonify({
                    "status": "success",
                    "title": title,
                    "duration_sec": duration,
                    "duration_str": duration_str,
                    "fps": info.get('fps', 30.0),
                    "width": info.get('width', 1280),
                    "height": info.get('height', 720),
                    "formats": sorted(list(heights)),
                    "is_youtube": True
                })
        else:
            import cv2
            if not os.path.exists(video_path):
                return jsonify({"error": f"本地影片不存在: {video_path}"}), 400
                
            cap = cv2.VideoCapture(video_path)
            if not cap.isOpened():
                return jsonify({"error": "無法開啟本地影片"}), 400
                
            fps = cap.get(cv2.CAP_PROP_FPS)
            total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            cap.release()
            
            if fps <= 0:
                fps = 25.0
            duration = total_frames / fps if total_frames > 0 else 0
            
            from utils import format_timestamp
            duration_str = format_timestamp(duration) if duration else "未知長度"
            
            # 本地影片的 format 為自身高度或更低
            local_formats = [360, 480, 720, 1080, 1440, 2160]
            formats = [lf for lf in local_formats if lf <= h]
            if h not in formats:
                formats.append(h)
                
            return jsonify({
                "status": "success",
                "title": os.path.basename(video_path),
                "duration_sec": duration,
                "duration_str": duration_str,
                "fps": fps,
                "width": w,
                "height": h,
                "formats": sorted(formats),
                "is_youtube": False
            })
    except Exception as e:
        return jsonify({"error": f"分析影片時出錯: {str(e)}"}), 500

@app.route('/api/start', methods=['POST'])
def start_task():
    """
    啟動投影片擷取背景任務。
    """
    global active_extractor, extractor_thread, extractor_status, start_time, active_video_path, active_output_dir
    
    if extractor_status == "running":
        return jsonify({"error": "已經有任務在執行中！"}), 400
        
    data = request.get_json() or {}
    video_path = data.get("video_path", "").strip()
    crop_mode = data.get("crop_mode", "full")
    crop_rect = data.get("crop_rect", "")
    frame_interval = float(data.get("frame_interval", 0.5))
    output_dir = data.get("output_dir", "output").strip()
    lowres_height_val = data.get("lowres_height", "360")
    delete_video_after_done = bool(data.get("delete_video_after_done", False))
    
    if not video_path:
        return jsonify({"error": "請提供影片檔案路徑或 YouTube 網址！"}), 400
        
    # 如果是本地檔案，先驗證是否存在
    if not video_path.startswith("http") and not os.path.exists(video_path):
        return jsonify({"error": f"本地影片檔案不存在: {video_path}"}), 400

    if not output_dir:
        output_dir = "output"
        
    # 新增時間戳隔離子目錄
    timestamp = time.strftime("task_%Y%m%d_%H%M%S")
    active_output_dir = os.path.join(output_dir, timestamp)
    os.makedirs(active_output_dir, exist_ok=True)

    # 重置輸出目錄，清空舊的投影片與預覽圖，以防前端展示混淆
    slides_dir = os.path.join(active_output_dir, "slides")
    if os.path.exists(slides_dir):
        shutil.rmtree(slides_dir)
    os.makedirs(slides_dir, exist_ok=True)
    
    # 移除舊報告與描述檔
    for old_file in ["report.csv", "slides.json", "report.html", "tutorial.html"]:
        p = os.path.join(active_output_dir, old_file)
        if os.path.exists(p):
            try:
                os.remove(p)
            except Exception:
                pass
        
    # 移除舊預覽影格
    preview_file = os.path.join(active_output_dir, "preview_frame.jpg")
    if os.path.exists(preview_file):
        os.remove(preview_file)
        
    # 移除舊的 YouTube 暫存檔
    if os.path.exists(active_output_dir):
        for f in os.listdir(active_output_dir):
            if f.startswith("yt_temp"):
                try:
                    os.remove(os.path.join(active_output_dir, f))
                except Exception:
                    pass
                    
    # 移除/重置日誌檔
    log_file = os.path.join(active_output_dir, "logs", "extractor.log")
    if os.path.exists(log_file):
        try:
            os.remove(log_file)
        except Exception:
            pass

    # 設定組態字典
    config = {
        "video_path": video_path,
        "output_dir": active_output_dir,
        "frame_interval": frame_interval,
        "crop_mode": crop_mode,
        "lowres_height": lowres_height_val,
        "delete_video_after_done": delete_video_after_done
    }
    if crop_mode == "manual" and crop_rect:
        config["crop_rect"] = crop_rect

    # 背景線程任務
    def task_runner():
        global extractor_status, active_extractor
        try:
            extractor_status = "running"
            active_extractor = VideoSlideExtractor(config)
            active_extractor.run()
            
            if active_extractor.stop_requested:
                extractor_status = "idle"
            else:
                extractor_status = "completed"
        except Exception as e:
            print(f"背景擷取線程出錯: {e}", file=sys.stderr)
            extractor_status = "error"

    # 初始化狀態並啟動線程
    active_video_path = video_path
    start_time = time.time()
    extractor_thread = threading.Thread(target=task_runner)
    extractor_thread.daemon = True
    extractor_thread.start()
    
    return jsonify({"message": "任務已啟動！", "output_dir": active_output_dir})

@app.route('/api/stop', methods=['POST'])
def stop_task():
    """
    停止執行中的背景擷取任務。
    """
    global active_extractor, extractor_status
    if extractor_status != "running" or active_extractor is None:
        return jsonify({"message": "目前沒有正在執行的任務。"})
        
    # 設定中斷標記，背景執行緒會在下一次迴圈跳出
    active_extractor.stop_requested = True
    return jsonify({"message": "已送出停止請求，系統正在安全終止並儲存報告..."})

@app.route('/api/status', methods=['GET'])
def get_status():
    """
    獲取目前擷取進度、已擷取投影片清單、以及最新日誌。
    """
    global extractor_status, start_time, active_video_path, active_output_dir
    
    # 計算執行時間
    elapsed_time = "00:00:00"
    if extractor_status == "running" and start_time is not None:
        secs = int(time.time() - start_time)
        mins, secs = divmod(secs, 60)
        hours, mins = divmod(mins, 60)
        elapsed_time = f"{hours:02d}:{mins:02d}:{secs:02d}"
        
    # 讀取 slides.json 取得已擷取投影片清單與狀態
    slides = []
    slides_json_file = os.path.join(active_output_dir, "slides.json")
    if os.path.exists(slides_json_file):
        try:
            import json
            with open(slides_json_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                raw_slides = data.get("slides", [])
                
                # 同步檢查實體檔案，確保 has_enhanced 與實體檔案一致
                slides_dir = os.path.join(active_output_dir, "slides")
                for s in raw_slides:
                    slide_no = s.get("slide_no")
                    enhanced_filename = f"slide_{slide_no:03d}_enhanced.png"
                    enhanced_exists = os.path.exists(os.path.join(slides_dir, enhanced_filename))
                    
                    slides.append({
                        "slide_no": slide_no,
                        "filename": s.get("filename"),
                        "timestamp": s.get("timestamp"),
                        "seconds": s.get("seconds", 0.0),
                        "has_enhanced": enhanced_exists
                    })
        except Exception:
            pass
            
    # 讀取最後 20 行日誌
    logs = []
    log_file = os.path.join(active_output_dir, "logs", "extractor.log")
    if os.path.exists(log_file):
        try:
            with open(log_file, "r", encoding="utf-8") as f:
                lines = f.readlines()
                logs = [line.strip() for line in lines[-20:]]
        except Exception:
            pass
            
    # 檢查即時預覽圖是否存在
    has_preview = os.path.exists(os.path.join(active_output_dir, "preview_frame.jpg"))
    preview_url = "/output/preview_frame.jpg" if has_preview else None
    
    return jsonify({
        "status": extractor_status,
        "video_path": active_video_path,
        "slides_count": len(slides),
        "elapsed_time": elapsed_time,
        "preview_url": preview_url,
        "slides": slides,
        "logs": logs
    })

@app.route('/api/export_pdf', methods=['POST'])
def export_pdf():
    """
    接收前端發送的檔名清單，將選定的投影片合成單一 PDF 並回傳檔案。
    """
    data = request.get_json() or {}
    output_dir = data.get("output_dir", "output").strip()
    filenames = data.get("filenames", [])
    pdf_resolution = data.get("pdf_resolution", "original")
    
    if not output_dir:
        output_dir = "output"
        
    if not filenames:
        return jsonify({"error": "請選擇至少一張投影片進行導出！"}), 400
        
    # 解析檔案完整路徑
    slides_dir = os.path.join(output_dir, "slides")
    image_paths = []
    for fname in filenames:
        # 防範目錄穿越攻擊，只保留純檔名
        safe_name = os.path.basename(fname)
        path = os.path.join(slides_dir, safe_name)
        if os.path.exists(path):
            image_paths.append(path)
            
    if not image_paths:
        return jsonify({"error": "找不到選取的投影片檔案！"}), 400
        
    try:
        from PIL import Image
        from reportlab.pdfgen import canvas
        
        pdf_path = os.path.join(output_dir, "slides.pdf")
        
        # 讀取第一張圖來初始化 PDF 預設頁面大小 (等比例 resize 後的大小)
        first_img = Image.open(image_paths[0])
        w_first, h_first = first_img.size
        page_w, page_h = w_first, h_first
        
        if pdf_resolution != 'original' and str(pdf_resolution).isdigit():
            target_h = int(pdf_resolution)
            if h_first > 0:
                scale = target_h / h_first
                page_h = target_h
                page_w = int(w_first * scale)
                
        # 建立 Canvas
        c = canvas.Canvas(pdf_path, pagesize=(page_w, page_h))
        
        for idx, img_path in enumerate(image_paths):
            img = Image.open(img_path)
            w_img, h_img = img.size
            
            # 決定當前頁面的尺寸
            curr_page_w, curr_page_h = page_w, page_h
            if pdf_resolution == 'original':
                curr_page_w, curr_page_h = w_img, h_img
            else:
                if h_img > 0:
                    scale = int(pdf_resolution) / h_img
                    curr_page_h = int(pdf_resolution)
                    curr_page_w = int(w_img * scale)
            
            c.setPageSize((curr_page_w, curr_page_h))
            
            # 使用 reportlab 的 drawImage 畫出圖片
            c.drawImage(img_path, 0, 0, width=curr_page_w, height=curr_page_h)
            
            # --- 精美頁碼疊加 ---
            c.saveState()
            c.setFillColorRGB(0, 0, 0, 0.4)  # 40% 透明度黑色圓角背景框
            rect_w, rect_h = 60, 20
            rect_x = curr_page_w - rect_w - 15
            rect_y = 15
            c.roundRect(rect_x, rect_y, rect_w, rect_h, 4, fill=True, stroke=False)
            
            # 繪製文字
            c.setFont("Helvetica-Bold", 10)
            c.setFillColorRGB(1, 1, 1)  # 白色字
            page_str = f"{idx + 1} / {len(image_paths)}"
            c.drawCentredString(rect_x + rect_w/2.0, rect_y + 5, page_str)
            c.restoreState()
            
            c.showPage()
            
        c.save()
        

        
        # 傳回 PDF 檔案給前端下載
        return send_file(pdf_path, as_attachment=True, download_name="slides.pdf", mimetype="application/pdf")
    except Exception as e:
        print(f"導出 PDF 出錯: {e}", file=sys.stderr)
        return jsonify({"error": f"合成 PDF 失敗: {str(e)}"}), 500

@app.route('/api/force_stop', methods=['POST'])
def force_stop():
    """
    強行關閉影片擷取任務，重置伺服器狀態為 Idle。
    """
    global active_extractor, extractor_status, extractor_thread
    
    msg_parts = []
    if active_extractor:
        # 1. 溫和標記
        active_extractor.stop_requested = True
        msg_parts.append("已發送停止指令")
        
        # 2. 強行釋放 VideoCapture 資源，這會使背景 loop 立即退出
        if hasattr(active_extractor, "cap") and active_extractor.cap is not None:
            try:
                active_extractor.cap.release()
                msg_parts.append("已釋放視訊解碼資源")
            except Exception as e:
                msg_parts.append(f"釋放解碼資源時異常: {e}")
                
    # 3. 強行重設後端狀態
    extractor_status = "idle"
    active_extractor = None
    extractor_thread = None
    msg_parts.append("伺服器狀態已強行重設為 IDLE")
    
    return jsonify({"message": "，".join(msg_parts) + "。您可以隨時重新啟動新任務！"})

@app.route('/api/clear_workspace', methods=['POST'])
def clear_workspace():
    """
    清空指定的輸出目錄，防止檔案殘留並釋放硬碟空間。
    """
    data = request.get_json() or {}
    output_dir = data.get("output_dir", "output").strip()
    if not output_dir:
        output_dir = "output"
        
    abs_path = os.path.abspath(output_dir)
    cwd_abs = os.path.abspath(os.getcwd())
    
    # 安全保護：防範清理系統根目錄或整個專案工作目錄
    if abs_path == cwd_abs or abs_path == "/" or len(abs_path) < len(cwd_abs):
        return jsonify({"error": "基於安全保護，禁止清空當前工作目錄本身或系統根目錄！請指定 output 子資料夾。"}), 400
        
    try:
        # 1. 清空 slides 目錄
        slides_dir = os.path.join(output_dir, "slides")
        if os.path.exists(slides_dir):
            shutil.rmtree(slides_dir)
        os.makedirs(slides_dir, exist_ok=True)
        
        # 2. 移除報告、描述檔與預覽影格
        for fname in ["report.csv", "slides.json", "report.html", "tutorial.html", "preview_frame.jpg"]:
            p = os.path.join(output_dir, fname)
            if os.path.exists(p):
                try:
                    os.remove(p)
                except Exception:
                    pass
                
        # 3. 移除舊 YouTube 暫存檔
        if os.path.exists(output_dir):
            for f in os.listdir(output_dir):
                if f.startswith("yt_temp"):
                    try:
                        os.remove(os.path.join(output_dir, f))
                    except Exception:
                        pass
                        
        # 4. 重置日誌檔
        log_file = os.path.join(output_dir, "logs", "extractor.log")
        if os.path.exists(log_file):
            try:
                os.remove(log_file)
            except Exception:
                pass
                
        return jsonify({"message": f"成功清空資料夾 {output_dir} 的所有暫存、日誌與投影片存檔！"})
    except Exception as e:
        return jsonify({"error": f"清空失敗: {str(e)}"}), 500

@app.route('/api/preview_enhance', methods=['POST'])
def preview_enhance():
    """
    影像強化即時預覽：只生成預覽用 Base64 資料，不寫入檔案。
    """
    data = request.get_json() or {}
    output_dir = data.get("output_dir", "").strip()
    filename = data.get("filename", "").strip()
    enhance_type = data.get("enhance_type", "").strip()
    
    if not output_dir or not filename or not enhance_type:
        return jsonify({"error": "參數不足"}), 400
        
    # 確保只針對原始檔案做影像處理，去除 _enhanced 字樣以取得原圖路徑
    base, ext = os.path.splitext(filename)
    orig_base = base.replace("_enhanced", "")
    orig_filename = f"{orig_base}{ext}"
    img_path = os.path.join(output_dir, "slides", orig_filename)
    if not os.path.exists(img_path):
        return jsonify({"error": f"找不到投影片原圖 {orig_filename}"}), 404
        
    try:
        import base64
        import cv2
        
        # 呼叫後端智慧放大與強化函數
        enhanced_img = enhance_image(img_path, enhance_type)
        
        # 編碼為 Base64
        _, buffer = cv2.imencode('.png', enhanced_img)
        base64_str = base64.b64encode(buffer).decode('utf-8')
        
        return jsonify({
            "status": "success",
            "preview_data": f"data:image/png;base64,{base64_str}"
        })
    except Exception as e:
        return jsonify({"error": f"預覽生成失敗: {str(e)}"}), 500

@app.route('/api/save_enhance', methods=['POST'])
def save_enhance():
    """
    儲存影像強化結果：將強化後的檔案以 slide_xxx_enhanced.png 寫入硬碟，並更新 slides.json 狀態。
    """
    data = request.get_json() or {}
    output_dir = data.get("output_dir", "").strip()
    filename = data.get("filename", "").strip()
    enhance_type = data.get("enhance_type", "").strip()
    
    if not output_dir or not filename or not enhance_type:
        return jsonify({"error": "參數不足"}), 400
        
    # 確保只針對原始檔案做影像處理，去除 _enhanced 字樣以取得原圖路徑
    base, ext = os.path.splitext(filename)
    orig_base = base.replace("_enhanced", "")
    orig_filename = f"{orig_base}{ext}"
    img_path = os.path.join(output_dir, "slides", orig_filename)
    if not os.path.exists(img_path):
        return jsonify({"error": f"找不到投影片原圖 {orig_filename}"}), 404
        
    try:
        import cv2
        import json
        
        # 呼叫後端強化函數
        enhanced_img = enhance_image(img_path, enhance_type)
        
        # 組合檔名並儲存
        base, ext = os.path.splitext(filename)
        # 防範重複疊加 _enhanced
        if base.endswith("_enhanced"):
            enhanced_filename = filename
        else:
            enhanced_filename = f"{base}_enhanced{ext}"
            
        enhanced_path = os.path.join(output_dir, "slides", enhanced_filename)
        cv2.imwrite(enhanced_path, enhanced_img)
        
        # 更新 slides.json 檔案
        json_path = os.path.join(output_dir, "slides.json")
        if os.path.exists(json_path):
            with open(json_path, "r", encoding="utf-8") as f:
                metadata = json.load(f)
                
            # 找到對應的投影片並更新 has_enhanced 標記
            for s in metadata.get("slides", []):
                # 去除 _enhanced 比對原投影片檔名
                orig_base = filename.replace("_enhanced", "")
                if s.get("filename") == orig_base or s.get("filename") == filename:
                    s["has_enhanced"] = True
                    
            with open(json_path, "w", encoding="utf-8") as f:
                json.dump(metadata, f, indent=2, ensure_ascii=False)
                
        return jsonify({
            "status": "success",
            "enhanced_filename": enhanced_filename
        })
    except Exception as e:
        return jsonify({"error": f"強化儲存失敗: {str(e)}"}), 500

@app.route('/api/batch_save_enhance', methods=['POST'])
def batch_save_enhance():
    """
    批次影像強化：對所有的投影片套用該強化方式，並更新 slides.json 與儲存增強版圖檔。
    """
    data = request.get_json() or {}
    output_dir = data.get("output_dir", "").strip()
    enhance_type = data.get("enhance_type", "").strip()
    
    if not output_dir or not enhance_type:
        return jsonify({"error": "參數不足"}), 400
        
    slides_dir = os.path.join(output_dir, "slides")
    if not os.path.exists(slides_dir):
        return jsonify({"error": "找不到投影片目錄"}), 404
        
    try:
        import cv2
        import json
        import sys
        
        json_path = os.path.join(output_dir, "slides.json")
        if not os.path.exists(json_path):
            return jsonify({"error": "找不到 slides.json 檔案"}), 404
            
        with open(json_path, "r", encoding="utf-8") as f:
            metadata = json.load(f)
            
        slides = metadata.get("slides", [])
        for s in slides:
            filename = s.get("filename")
            if not filename:
                continue
            
            # 確保使用原始圖進行強化，避免使用已強化的圖再次強化
            orig_base = filename.replace("_enhanced", "")
            img_path = os.path.join(slides_dir, orig_base)
            if not os.path.exists(img_path):
                if not orig_base.endswith(".png"):
                    orig_base = f"{orig_base}.png"
                img_path = os.path.join(slides_dir, orig_base)
                if not os.path.exists(img_path):
                    continue
            
            # 呼叫後端強化函數
            try:
                enhanced_img = enhance_image(img_path, enhance_type)
            except Exception as ee:
                print(f"無法強化投影片 {filename}: {ee}", file=sys.stderr)
                continue
            
            # 組合檔名並儲存
            base, ext = os.path.splitext(orig_base)
            enhanced_filename = f"{base}_enhanced{ext}"
            enhanced_path = os.path.join(slides_dir, enhanced_filename)
            
            cv2.imwrite(enhanced_path, enhanced_img)
            s["has_enhanced"] = True
            
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(metadata, f, indent=2, ensure_ascii=False)
            
        return jsonify({
            "status": "success",
            "message": f"成功批次套用強化技術：{enhance_type}"
        })
    except Exception as e:
        return jsonify({"error": f"批次強化失敗: {str(e)}"}), 500


@app.route('/api/export_report', methods=['POST'])
def export_report():
    """
    動態生成適合人類閱讀的 HTML 報表與獨立教材 HTML。
    """
    data = request.get_json() or {}
    output_dir = data.get("output_dir", "").strip()
    filenames = data.get("filenames", [])
    detail_level = data.get("detail_level", "detailed").strip()
    
    if not output_dir or not filenames:
        return jsonify({"error": "參數不足"}), 400
        
    json_path = os.path.join(output_dir, "slides.json")
    if not os.path.exists(json_path):
        return jsonify({"error": "找不到工作區的 slides.json 資訊檔！"}), 404
        
    try:
        import json
        with open(json_path, "r", encoding="utf-8") as f:
            metadata = json.load(f)
            
        # 產出教材與說明書
        tutorial_path = os.path.join(output_dir, "tutorial.html")
        write_tutorial_html(tutorial_path)
        
        # 產出 report.html
        report_path = os.path.join(output_dir, "report.html")
        generate_report_html(report_path, metadata, filenames, detail_level)
        
        return send_file(report_path, as_attachment=True, download_name="report.html", mimetype="text/html")
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"error": f"產出 HTML 報表失敗: {str(e)}"}), 500

def write_tutorial_html(file_path):
    """
    產出影像處理與專案理念之 HTML 教材。
    """
    html_content = """<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Video Slide Extractor 運作原理與影像處理教材</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Noto+Sans+TC:wght@300;400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Outfit', 'Noto Sans TC', sans-serif;
            background-color: #0b0f19;
            color: #f1f5f9;
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 900px;
            margin: 40px auto;
            padding: 20px;
        }
        .header {
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: 16px;
            padding: 30px;
            text-align: center;
            margin-bottom: 30px;
        }
        h1 {
            color: #38bdf8;
            font-size: 2rem;
            margin-top: 0;
        }
        .subtitle {
            color: #94a3b8;
            font-size: 1.1rem;
        }
        .card {
            background: rgba(30, 41, 59, 0.4);
            border: 1px solid rgba(255,255,255,0.05);
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 24px;
            backdrop-filter: blur(10px);
        }
        h2 {
            color: #34d399;
            font-size: 1.4rem;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            padding-bottom: 8px;
            margin-top: 0;
        }
        .workflow {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin: 30px 0;
        }
        .step {
            background: linear-gradient(90deg, #1e293b 0%, #0f172a 100%);
            border: 1px solid #38bdf8;
            border-radius: 8px;
            padding: 12px 24px;
            width: 80%;
            text-align: center;
            font-weight: 600;
            position: relative;
        }
        .arrow {
            color: #38bdf8;
            font-size: 1.5rem;
            margin: 8px 0;
        }
        .highlight {
            color: #38bdf8;
            font-weight: 600;
        }
        ul {
            padding-left: 20px;
        }
        li {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Video Slide Extractor 運作原理與影像教材</h1>
            <p class="subtitle">探索底層電腦視覺與知識管理系統的工程設計</p>
        </div>

        <div class="card">
            <h2>一、專案精神與核心理念 (KM Philosophy)</h2>
            <p>本專案的核心目標在於：<span class="highlight">「捕捉專家經驗，快速收納為知識管理 (KM) 資料庫」</span>。</p>
            <ul>
                <li><span class="highlight">高效知識沈澱</span>：使用者不需花費數小時反覆觀看長篇教學影片，即可透過此程式快速抽離出演講、簡報或課堂的精華大綱。</li>
                <li><span class="highlight">零執行成本 (No AI API Cost)</span>：本專案在開發時期利用了 AI 的輔助進行高效率提效，但在運作執行時，<strong>完全不消耗任何 AI API Token</strong>。全部運算皆由本機高效電腦視覺演算法完成，免去高昂的 API 使用年費與雲端主機依賴。</li>
                <li><span class="highlight">人機協作控制 (Human-in-the-Loop)</span>：程式演算法負責進行巨量影格的粗篩與降噪，並將最終決定權交付給人類進行版本比對與確認，保證產出品質的 100% 精確性。</li>
            </ul>
        </div>

        <div class="card">
            <h2>二、核心演算法工作流程 (Algorithm Workflow)</h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px; margin-top: 20px;">
                <!-- 左側：視覺化流程圖 -->
                <div>
                    <h3 style="color: #38bdf8; font-size: 1.1rem; margin-top: 0; margin-bottom: 15px; border-bottom: 1px dashed rgba(255,255,255,0.1); padding-bottom: 5px;">🎨 視覺化工作流 (Visual Flow)</h3>
                    <div class="workflow">
                        <div class="step">1. 影片分析 (讀取 Metadata/解析影片格式)</div>
                        <div class="arrow">↓</div>
                        <div class="step">2. 畫面變化偵測 (低畫質快速影格 MAE 差值比對)</div>
                        <div class="arrow">↓</div>
                        <div class="step">3. 換頁推測 (在影格變化波峰處進入穩定度追蹤)</div>
                        <div class="arrow">↓</div>
                        <div class="step">4. 相似度分析 (HSV 直方圖與結構度比對)</div>
                        <div class="arrow">↓</div>
                        <div class="step">5. 模糊檢測 (Laplacian 邊緣變異數過濾黑底/過渡/模糊影格)</div>
                        <div class="arrow">↓</div>
                        <div class="step">6. 重複頁排除 (利用 dHash 漢明距離與平均色彩濾除重複簡報)</div>
                        <div class="arrow">↓</div>
                        <div class="step">7. 候選投影片 (原解析度原汁原味輸出)</div>
                    </div>
                </div>
                
                <!-- 右側：Plain text 複製區（完全還原使用者截圖之視覺感受） -->
                <div>
                    <h3 style="color: #38bdf8; font-size: 1.1rem; margin-top: 0; margin-bottom: 15px; border-bottom: 1px dashed rgba(255,255,255,0.1); padding-bottom: 5px;">📝 純文字版 (Plain text)</h3>
                    <div style="background: #ffffff; color: #000000; border-radius: 12px; padding: 20px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; box-shadow: 0 4px 12px rgba(0,0,0,0.1); border: 1px solid #e2e8f0; height: calc(100% - 40px); box-sizing: border-box;">
                        <div style="font-weight: 600; color: #64748b; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 1px solid #f1f5f9; padding-bottom: 8px; margin-bottom: 15px;">Plain text</div>
                        <div style="font-size: 1.1rem; line-height: 1.6; font-weight: 600; font-family: inherit; color: #1e293b;">
                            影片分析<br>
                            ↓<br>
                            畫面變化偵測<br>
                            ↓<br>
                            換頁推測<br>
                            ↓<br>
                            相似度分析<br>
                            ↓<br>
                            模糊檢測<br>
                            ↓<br>
                            重複頁排除<br>
                            ↓<br>
                            候選投影片
                        </div>
                    </div>
                </div>
            </div>
            <p style="margin-top: 25px;">本流程源自於車流量與「變動監控」技術（類似於高速公路變動監控演算法），將連續的影像流拆解，利用數學矩陣與空間域算法去精確推算「靜止」與「跳頁」的分界點。</p>
        </div>

        <div class="card">
            <h2>三、影像處理與強化技術說明</h2>
            <ul>
                <li><strong>文字邊緣銳化 (Unsharp Masking)</strong>：使用 Gaussian 模糊濾波器將原圖平滑化，再與原圖相減得到高頻邊緣，將其乘以權重疊加回原圖。這能使模糊的簡報文字字體邊緣變得更清晰，顯著改善可讀性。</li>
                <li><strong>對比度增強 (CLAHE)</strong>：對比度限制自適應直方圖均衡化。它在網格區域內獨立運算，能動態增強亮暗文字與背景的對比，且不會放大邊緣噪聲，非常適合複雜色彩或暗色主題簡報。</li>
                <li><strong>邊緣保留去噪 (Bilateral Filter)</strong>：結合空間鄰近度與像素亮度相似度的雙邊權重濾波。它在平滑相機噪聲或影片壓縮馬賽克雜訊時，能徹底保護文字邊緣的對比度，使文字不發糊。</li>
                <li><strong>文檔講義化模式 (Scan/Document Mode)</strong>：利用局部自適應閾值二值化 (Adaptive Thresholding)，根據像素周圍的平均亮度計算閥值，將文字轉化為純黑，背景轉化為純白。這能使圖片體積縮小 90%，並呈現如同專業掃描器印出的講義質感。</li>
            </ul>
        </div>

        <div class="card">
            <h2>四、專案版本對照與資源釋出方式</h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 20px; margin-top: 15px;">
                <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.05); padding: 16px; border-radius: 8px;">
                    <h3 style="color: #94a3b8; margin-top: 0; font-size: 1.1rem; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 6px;">
                        <span>v1.x (本機 Python 核心版)</span>
                        <span style="color: #ef4444; background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.2); font-size: 0.75rem; padding: 2px 6px; border-radius: 4px; font-weight: bold;">商業機密</span>
                    </h3>
                    <p style="font-size: 0.85rem; color: #94a3b8; margin: 8px 0;">提供 7 階段電腦視覺核心擷取演算法與基礎影像強化。僅本機運行。</p>
                    <p style="font-size: 0.85rem; color: #ef4444; font-weight: 600; margin-bottom: 0;">🔒 商業機密，不提供資源包與源碼</p>
                </div>
                
                <div style="background: rgba(56,189,248,0.03); border: 1px solid rgba(56,189,248,0.1); padding: 16px; border-radius: 8px;">
                    <h3 style="color: #38bdf8; margin-top: 0; font-size: 1.1rem; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(56,189,248,0.05); padding-bottom: 6px;">
                        <span>v2.x (本機 Python 協作版)</span>
                        <span style="color: #ef4444; background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.2); font-size: 0.75rem; padding: 2px 6px; border-radius: 4px; font-weight: bold;">商業機密</span>
                    </h3>
                    <p style="font-size: 0.85rem; color: #94a3b8; margin: 8px 0;">升級 Split Slider 互動比對介面、熱鍵控制、2x/4x 智慧放大、批次一鍵強化與非疊加單次變動。</p>
                    <p style="font-size: 0.85rem; color: #ef4444; font-weight: 600; margin-bottom: 0;">🔒 商業機密，不提供資源包與源碼</p>
                </div>
                
                <div style="background: rgba(52,211,153,0.03); border: 1px solid rgba(52,211,153,0.1); padding: 16px; border-radius: 8px;">
                    <h3 style="color: #34d399; margin-top: 0; font-size: 1.1rem; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(52,211,153,0.05); padding-bottom: 6px;">
                        <span>Demo 版 (網頁模擬 POC)</span>
                        <span style="color: #34d399; background: rgba(52,211,153,0.1); border: 1px solid rgba(52,211,153,0.2); font-size: 0.75rem; padding: 2px 6px; border-radius: 4px; font-weight: bold;">公開展示</span>
                    </h3>
                    <p style="font-size: 0.85rem; color: #94a3b8; margin: 8px 0;">靜態模擬 v2.x 體驗。前端免伺服器重播真實擷取日誌、變動曲線與 Split Slider 比對，支援導出 PDF/HTML。</p>
                    <p style="font-size: 0.8rem; color: #38bdf8; margin: 4px 0;">🔌 支援專屬 Chrome 匯入與擷取外掛，提供「僅輸出圖 (PNG)」與「輸出圖 + PDF」雙下載模式，徹底解決連續下載遮擋 PDF 按鈕的問題。</p>
                    <div style="font-size: 0.8rem; color: #f59e0b; font-weight: 500; border-top: 1px dashed rgba(245,158,11,0.2); padding-top: 6px; margin-top: 8px;">
                        ⚠️ 此網頁展示版無法直接解析新影片，僅為模擬展示版。<br>
                        👉 <b>需要本機可執行 Python 完整版，請聯繫 Force 老師。</b>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
"""
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(html_content)

def generate_report_html(file_path, metadata, selected_filenames, detail_level):
    """
    動態生成排版精美、內含專案精神與分析教材的人類好讀 HTML 報表。
    """
    import os
    
    # 過濾出被勾選的投影片
    slides_info = []
    selected_basenames = [os.path.basename(f) for f in selected_filenames]
    
    for s in metadata.get("slides", []):
        filename = s.get("filename")
        enhanced_filename = filename.replace(".png", "_enhanced.png")
        
        # 判斷用戶選擇的是原始還是強化
        chosen_name = filename
        if enhanced_filename in selected_basenames:
            chosen_name = enhanced_filename
            
        if filename in selected_basenames or enhanced_filename in selected_basenames:
            slides_info.append((s, chosen_name))
            
    # 建立 HTML 頁面
    title = metadata.get("title", "投影片擷取報表")
    video_path = metadata.get("video_path", "")
    duration_str = metadata.get("duration_str", "未知")
    res_str = f"{metadata.get('width', 0)}x{metadata.get('height', 0)}"
    
    # 專案精神 HTML 片段
    spirit_html = """
    <div class="spirit-banner">
        <div class="spirit-logo">💡 專案核心精神 (Project Credo)</div>
        <div class="spirit-grid">
            <div class="spirit-card">
                <h3>📌 知識管理 (KM) 與經驗傳承</h3>
                <p>本專案旨在捕捉專家影片中的精華經驗，並將其高效率儲存為結構化的知識庫檔案，建立起個人與企業的知識管理體系。</p>
            </div>
            <div class="spirit-card">
                <h3>⚡ 零運行成本運算 (No Token Cost)</h3>
                <p>執行過程完全依靠 OpenCV 本機電腦視覺演算法（MAE 影格追蹤、dHash 去重與邊緣變異分析），<b>執行時完全不耗費任何 AI API Token</b>。</p>
            </div>
            <div class="spirit-card">
                <h3>🤝 人機協調驗證 (Human-in-the-Loop)</h3>
                <p>利用電腦視覺做大批量自動化過濾，再透過「雙向滑塊對比」交由人類做出最終的版本確認，是極佳的人機協作實踐。</p>
            </div>
        </div>
    </div>
    """
    
    # 運作原理教材 HTML 片段
    workflow_html = """
    <div class="workflow-section">
        <h3>🧬 簡報擷取技術工作流程 (Workflow Overview)</h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px; margin-top: 20px;">
            <!-- 視覺化流程 -->
            <div>
                <h4 style="color: #38bdf8; font-size: 1rem; margin-top: 0; margin-bottom: 15px; border-bottom: 1px dashed rgba(255,255,255,0.08); padding-bottom: 5px;">🎨 視覺化工作流 (Visual Flow)</h4>
                <div class="workflow-steps">
                    <div class="step-badge">1. 影片分析</div>
                    <div class="step-arrow">→</div>
                    <div class="step-badge">2. 畫面變化偵測</div>
                    <div class="step-arrow">→</div>
                    <div class="step-badge">3. 換頁推測</div>
                    <div class="step-arrow">→</div>
                    <div class="step-badge">4. 相似度分析</div>
                    <div class="step-arrow">→</div>
                    <div class="step-badge">5. 模糊檢測</div>
                    <div class="step-arrow">→</div>
                    <div class="step-badge">6. 重複頁排除</div>
                    <div class="step-arrow">→</div>
                    <div class="step-badge">7. 候選投影片</div>
                </div>
            </div>
            
            <!-- Plain text 對照 -->
            <div>
                <h4 style="color: #38bdf8; font-size: 1rem; margin-top: 0; margin-bottom: 15px; border-bottom: 1px dashed rgba(255,255,255,0.08); padding-bottom: 5px;">📝 純文字版 (Plain text)</h4>
                <div style="background: #ffffff; color: #000000; border-radius: 12px; padding: 20px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; box-shadow: 0 4px 12px rgba(0,0,0,0.1); border: 1px solid #e2e8f0; width: 100%; box-sizing: border-box; text-align: left;">
                    <div style="font-weight: 600; color: #64748b; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 1px solid #f1f5f9; padding-bottom: 8px; margin-bottom: 15px;">Plain text</div>
                    <div style="font-size: 1.1rem; line-height: 1.6; font-weight: 600; font-family: inherit; color: #1e293b;">
                        影片分析<br>
                        ↓<br>
                        畫面變化偵測<br>
                        ↓<br>
                        換頁推測<br>
                        ↓<br>
                        相似度分析<br>
                        ↓<br>
                        模糊檢測<br>
                        ↓<br>
                        重複頁排除<br>
                        ↓<br>
                        候選投影片
                    </div>
                </div>
            </div>
        </div>
        <p class="workflow-desc" style="margin-top: 25px;">本系統演算法原理基於車流量與「變動監控」技術（類似於高速公路變動監控演算法），利用數學矩陣與空間域算法去精確推算「靜止」與「跳頁」的分界點，排除干擾畫面。</p>
    </div>
    """
    
    version_html = """
    <div class="workflow-section" style="margin-top: 30px;">
        <h3>📦 Video Slide Extractor 專案版本對照說明</h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 20px; margin-top: 15px; text-align: left;">
            <div style="background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.05); padding: 15px; border-radius: 8px;">
                <h4 style="margin-top:0; color:#94a3b8; font-size:1rem; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(255,255,255,0.05); padding-bottom:6px;">
                    <span>v1.x (本機 Python 核心版)</span>
                    <span style="color:#ef4444; background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.2); font-size:0.75rem; padding:1px 5px; border-radius:4px; font-weight:bold;">商業機密</span>
                </h4>
                <p style="font-size:0.8rem; color:#64748b; line-height:1.4; margin: 8px 0 0 0;">實作核心電腦視覺(CV)簡報擷取演算法與基礎影像處理。不提供任何資源包與原始碼。</p>
                <p style="font-size:0.8rem; color:#ef4444; font-weight:600; margin: 6px 0 0 0;">🔒 商業機密，不提供資源包與源碼</p>
            </div>
            <div style="background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.05); padding: 15px; border-radius: 8px;">
                <h4 style="margin-top:0; color:#38bdf8; font-size:1rem; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(255,255,255,0.05); padding-bottom:6px;">
                    <span>v2.x (本機 Python 協作版)</span>
                    <span style="color:#ef4444; background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.2); font-size:0.75rem; padding:1px 5px; border-radius:4px; font-weight:bold;">商業機密</span>
                </h4>
                <p style="font-size:0.8rem; color:#64748b; line-height:1.4; margin: 8px 0 0 0;">新增 Split Slider 互動比對、熱鍵控制、2x/4x 智慧放大、批次一鍵強化與非疊加單次變動。</p>
                <p style="font-size:0.8rem; color:#ef4444; font-weight:600; margin: 6px 0 0 0;">🔒 商業機密，不提供資源包與源碼</p>
            </div>
            <div style="background: rgba(52,211,153,0.02); border: 1px solid rgba(52,211,153,0.08); padding: 15px; border-radius: 8px;">
                <h4 style="margin-top:0; color:#34d399; font-size:1rem; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(52,211,153,0.05); padding-bottom:6px;">
                    <span>Demo 版 (網頁模擬 POC)</span>
                    <span style="color:#34d399; background:rgba(52,211,153,0.1); border:1px solid rgba(52,211,153,0.2); font-size:0.75rem; padding:1px 5px; border-radius:4px; font-weight:bold;">公開展示</span>
                </h4>
                <p style="font-size:0.8rem; color:#94a3b8; line-height:1.4; margin: 8px 0 0 0;">純前端模擬 v2.x 真實擷取與對比軌跡重播，支援導出 PDF/HTML。</p>
                <p style="font-size:0.75rem; color:#38bdf8; line-height:1.4; margin: 4px 0 0 0;">🔌 支援專屬 Chrome 匯入外掛，提供「僅輸出圖 (PNG)」與「輸出圖 + PDF」雙下載模式，防止連續下載通知遮擋 PDF 按鈕。</p>
                <div style="font-size:0.75rem; color:#f59e0b; font-weight:500; border-top:1px dashed rgba(245,158,11,0.2); padding-top:4px; margin-top:4px;">
                    ⚠️ 本版僅為靜態 demo 模擬版，網頁上無法直接解析新影片。<br>
                    👉 <b>需要本機可執行 Python 完整版，請聯繫 Force 老師。</b>
                </div>
            </div>
        </div>
    </div>
    """
    
    # 投影片列表生成
    output_dir = os.path.dirname(file_path)
    slides_list_html = ""
    import base64
    for s, file_to_use in slides_info:
        enhanced_badge = '<span class="badge badge-enhance">已影像強化</span>' if "enhanced" in file_to_use else '<span class="badge badge-orig">原始擷取</span>'
        
        detail_fields_html = ""
        if detail_level == "standard" or detail_level == "detailed":
            detail_fields_html += f'<div class="meta-item"><strong>精確秒數:</strong> {s.get("seconds"):.2f} 秒</div>'
            
        if detail_level == "detailed":
            detail_fields_html += f"""
            <div class="meta-item"><strong>dHash 影像指紋:</strong> <code>{s.get("dhash")}</code></div>
            <div class="meta-item"><strong>平均色彩 (RGB):</strong> <code>{s.get("mean_color")}</code></div>
            <div class="meta-item"><strong>模糊度分數:</strong> <code>{s.get("blur_value", 0.0):.1f}</code></div>
            """
            
        # 讀取實體檔案並轉換成 Base64 嵌入 HTML
        slide_img_path = os.path.join(output_dir, "slides", file_to_use)
        img_src = ""
        if os.path.exists(slide_img_path):
            try:
                with open(slide_img_path, "rb") as img_f:
                    img_data = img_f.read()
                    base64_data = base64.b64encode(img_data).decode('utf-8')
                    img_src = f"data:image/png;base64,{base64_data}"
            except Exception as e:
                print("Base64 轉換失敗:", e)
                img_src = f"slides/{file_to_use}"
        else:
            img_src = f"slides/{file_to_use}"
            
        slides_list_html += f"""
        <div class="slide-card">
            <div class="slide-image-box">
                <img src="{img_src}" alt="Slide {s.get("slide_no")}">
            </div>
            <div class="slide-meta-box">
                <div class="slide-title">
                    <span>投影片 #{s.get("slide_no"):03d}</span>
                    {enhanced_badge}
                </div>
                <div class="meta-item"><strong>時間點:</strong> {s.get("timestamp")}</div>
                {detail_fields_html}
            </div>
        </div>
        """
        
    html_content = f"""<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>投影片擷取任務報告 - {title}</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Noto+Sans+TC:wght@300;400;500;700&display=swap" rel="stylesheet">
    <style>
        body {{
            font-family: 'Outfit', 'Noto Sans TC', sans-serif;
            background-color: #0b0f19;
            color: #f1f5f9;
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }}
        .container {{
            max-width: 1000px;
            margin: 40px auto;
            padding: 20px;
        }}
        .header {{
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: 16px;
            padding: 30px;
            margin-bottom: 30px;
        }}
        h1 {{
            color: #38bdf8;
            font-size: 1.8rem;
            margin-top: 0;
        }}
        .metadata-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 20px;
            border-top: 1px solid rgba(255,255,255,0.08);
            padding-top: 20px;
            font-size: 0.9rem;
            color: #94a3b8;
        }}
        .metadata-grid span strong {{
            color: #f1f5f9;
        }}
        /* 專案精神樣式 */
        .spirit-banner {{
            background: rgba(56, 189, 248, 0.05);
            border: 1px dashed rgba(56, 189, 248, 0.3);
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 30px;
        }}
        .spirit-logo {{
            color: #38bdf8;
            font-weight: 700;
            font-size: 1.1rem;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
        }}
        .spirit-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }}
        .spirit-card h3 {{
            color: #34d399;
            font-size: 0.95rem;
            margin-top: 0;
            margin-bottom: 8px;
        }}
        .spirit-card p {{
            font-size: 0.85rem;
            color: #94a3b8;
            margin: 0;
        }}
        /* 工作流程樣式 */
        .workflow-section {{
            background: rgba(30, 41, 59, 0.4);
            border: 1px solid rgba(255,255,255,0.05);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 30px;
        }}
        .workflow-section h3 {{
            color: #f1f5f9;
            font-size: 1.1rem;
            margin-top: 0;
            margin-bottom: 15px;
        }}
        .workflow-steps {{
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 8px;
            margin-bottom: 12px;
        }}
        .step-badge {{
            background: rgba(255,255,255,0.06);
            border: 1px solid rgba(255,255,255,0.1);
            color: #38bdf8;
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 0.8rem;
            font-weight: 600;
        }}
        .step-arrow {{
            color: #475569;
            font-weight: bold;
        }}
        .workflow-desc {{
            font-size: 0.85rem;
            color: #94a3b8;
            margin: 0;
        }}
        /* 投影片清單樣式 */
        .slides-container {{
            display: flex;
            flex-direction: column;
            gap: 24px;
        }}
        .slide-card {{
            display: flex;
            background: rgba(30, 41, 59, 0.3);
            border: 1px solid rgba(255,255,255,0.05);
            border-radius: 12px;
            overflow: hidden;
            backdrop-filter: blur(10px);
            transition: transform 0.2s;
        }}
        .slide-card:hover {{
            transform: translateY(-2px);
            border-color: rgba(56, 189, 248, 0.2);
        }}
        .slide-image-box {{
            flex: 0 0 320px;
            background: #000;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            border-right: 1px solid rgba(255,255,255,0.05);
        }}
        .slide-image-box img {{
            width: 100%;
            height: auto;
            max-height: 200px;
            object-fit: contain;
            display: block;
        }}
        .slide-meta-box {{
            flex: 1;
            padding: 20px;
        }}
        .slide-title {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 1.2rem;
            font-weight: 700;
            color: #f1f5f9;
            margin-bottom: 12px;
            border-bottom: 1px solid rgba(255,255,255,0.08);
            padding-bottom: 8px;
        }}
        .badge {{
            font-size: 0.75rem;
            padding: 4px 8px;
            border-radius: 4px;
            font-weight: 600;
        }}
        .badge-orig {{
            background: rgba(255, 255, 255, 0.08);
            color: #94a3b8;
            border: 1px solid rgba(255,255,255,0.1);
        }}
        .badge-enhance {{
            background: rgba(52, 211, 153, 0.1);
            color: #34d399;
            border: 1px solid rgba(52, 211, 153, 0.3);
        }}
        .meta-item {{
            font-size: 0.9rem;
            color: #94a3b8;
            margin-bottom: 6px;
        }}
        .meta-item strong {{
            color: #cbd5e1;
        }}
        .meta-item code {{
            background: rgba(0,0,0,0.3);
            padding: 2px 6px;
            border-radius: 4px;
            color: #f43f5e;
            font-family: monospace;
        }}
        @media (max-width: 768px) {{
            .slide-card {{
                flex-direction: column;
            }}
            .slide-image-box {{
                flex: none;
                width: 100%;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>投影片自動分析與擷取報告</h1>
            <div class="metadata-grid">
                <span>影片名稱: <strong>{title}</strong></span>
                <span>影片路徑/網址: <strong>{video_path}</strong></span>
                <span>總長度: <strong>{duration_str}</strong></span>
                <span>解析度: <strong>{res_str}</strong></span>
                <span>匯出數量: <strong>{len(slides_info)} 張投影片</strong></span>
                <span>報告等級: <strong>{detail_level.upper()}</strong></span>
            </div>
        </div>

        {spirit_html}
        
        {workflow_html}

        {version_html}

        <div class="slides-container">
            {slides_list_html}
        </div>
    </div>
</body>
</html>
"""
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(html_content)

def main():
    port = 5001
    print("==================================================")
    print(f" Video Slide Extractor Web 控制端")
    print(f" 請用瀏覽器開啟: http://127.0.0.1:{port}")
    print("==================================================")
    
    # 啟動 Flask app 監聽本地端
    app.run(host="127.0.0.1", port=port, debug=False)

if __name__ == "__main__":
    main()
