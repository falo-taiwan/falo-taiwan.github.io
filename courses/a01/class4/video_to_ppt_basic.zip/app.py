import os
import sys
import json
import argparse
from typing import Dict, Any

from extractor import VideoSlideExtractor

def load_config_file(filepath: str) -> Dict[str, Any]:
    """
    從 JSON 檔案載入自訂設定。
    """
    if not os.path.exists(filepath):
        print(f"警告: 設定檔 {filepath} 不存在，將使用預設閾值參數。")
        return {}
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"錯誤: 無法讀取或解析設定檔 {filepath}: {e}")
        sys.exit(1)

def main():
    parser = argparse.ArgumentParser(
        description="Video Slide Extractor (影片投影片萃取工具) - 從課程/簡報影片中自動辨識並擷取高畫質投影片。"
    )
    
    # 必填參數：影片路徑
    parser.add_argument(
        "video_path",
        type=str,
        help="輸入的影片路徑 (例如 demo.mp4)"
    )
    
    # 常用輸出與抽樣設定
    parser.add_argument(
        "-o", "--output-dir",
        type=str,
        default="output",
        help="輸出成果的目錄路徑 (預設為 'output')"
    )
    parser.add_argument(
        "-i", "--frame-interval",
        type=float,
        default=0.5,
        help="抽幀間隔時間（秒，預設 0.5 秒）"
    )
    
    # 裁切選項
    parser.add_argument(
        "-m", "--crop-mode",
        type=str,
        choices=["full", "auto", "manual"],
        default="full",
        help="裁切模式。'full': 全畫面 (不裁切); 'auto': 自動辨識簡報區域; 'manual': 手動指定區域"
    )
    parser.add_argument(
        "-c", "--crop-rect",
        type=str,
        help="手動裁切的座標，格式為 'x,y,w,h' 或百分比 'x%%,y%%,w%%,h%%' (僅在 --crop-mode 為 manual 時生效)"
    )
    
    # 進階設定檔 (JSON 格式，用以覆寫內部檢驗閾值)
    parser.add_argument(
        "--config",
        type=str,
        help="進階設定檔 (JSON) 的路徑，可自訂所有過濾閾值"
    )

    args = parser.parse_args()

    # 檢查輸入檔案是否存在
    if not os.path.exists(args.video_path):
        print(f"錯誤: 輸入影片檔案不存在: {args.video_path}")
        sys.exit(1)

    # 彙整設定參數
    config: Dict[str, Any] = {}
    
    # 1. 若有提供設定檔，先載入
    if args.config:
        config.update(load_config_file(args.config))
        
    # 2. 以 CLI 傳入參數覆寫/填補設定
    config["video_path"] = args.video_path
    config["output_dir"] = args.output_dir
    config["frame_interval"] = args.frame_interval
    config["crop_mode"] = args.crop_mode
    
    if args.crop_rect:
        config["crop_rect"] = args.crop_rect

    # 啟動 Extractor
    try:
        extractor = VideoSlideExtractor(config)
        extractor.run()
    except Exception as e:
        print(f"\n執行過程中發生未預期錯誤:\n{e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
