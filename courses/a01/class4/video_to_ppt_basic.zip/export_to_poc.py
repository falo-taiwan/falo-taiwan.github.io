import os
import re
import json
import shutil

def parse_log_file(log_path):
    """
    解析 extractor.log，提取 MAE 曲線與各階段日誌事件。
    """
    mae_points = []
    log_events = []
    
    if not os.path.exists(log_path):
        print(f"警告: 找不到日誌檔 {log_path}，將使用預設空資料。")
        return mae_points, log_events
        
    # 用於比對時間點的 regex
    # 格式舉例: 偵測到換頁觸發於 00:10:36 (MAE: 8.39, Corr: 0.996)
    mae_pattern = re.compile(r"偵測到換頁觸發於 (\d{2}):(\d{2}):(\d{2}).*?MAE: ([\d\.]+)")
    # 格式舉例: [2026-06-23 00:12:24] [INFO] 訊息
    line_pattern = re.compile(r"\[\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\] \[(INFO|WARNING|ERROR)\] (.*)")
    
    # 轉換時間為秒數
    def hms_to_seconds(h, m, s):
        return int(h) * 3600 + int(m) * 60 + float(s)

    with open(log_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
                
            # 1. 提取 MAE 點
            mae_match = mae_pattern.search(line)
            if mae_match:
                h, m, s, mae_val = mae_match.groups()
                sec = hms_to_seconds(h, m, s)
                mae_points.append({"sec": sec, "mae": float(mae_val)})
                
            # 2. 提取日誌事件
            line_match = line_pattern.search(line)
            if line_match:
                level, msg = line_match.groups()
                
                # 從消息中抓取影片內部的秒數（如果含有類似 00:00:12 格式）
                sec_match = re.search(r"(\d{2}):(\d{2}):(\d{2})", msg)
                event_sec = 0
                if sec_match:
                    h, m, s = sec_match.groups()
                    event_sec = hms_to_seconds(h, m, s)
                    
                log_events.append({
                    "sec": event_sec,
                    "type": level.lower(),
                    "text": msg
                })
                
    # 按照影片秒數排序
    log_events.sort(key=lambda x: x["sec"])
    return mae_points, log_events

def export_workspace_to_poc(output_dir, target_poc_dir):
    """
    將實際執行任務的 output 目錄轉換並包裝為靜態 POC 資料包。
    """
    print(f"開始從實際目錄 [{output_dir}] 導出靜態 POC 素材...")
    
    # 1. 檢查路徑
    slides_json_path = os.path.join(output_dir, "slides.json")
    if not os.path.exists(slides_json_path):
        print(f"錯誤: 找不到 {slides_json_path}！請先運行至少一次分析任務。")
        return False
        
    # 建立目標資料夾
    os.makedirs(target_poc_dir, exist_ok=True)
    poc_assets_dir = os.path.join(target_poc_dir, "poc_assets")
    os.makedirs(poc_assets_dir, exist_ok=True)
    
    # 2. 複製圖檔
    src_slides_dir = os.path.join(output_dir, "slides")
    copied_count = 0
    if os.path.exists(src_slides_dir):
        for fname in os.listdir(src_slides_dir):
            if fname.endswith(".png"):
                src_file = os.path.join(src_slides_dir, fname)
                dest_file = os.path.join(poc_assets_dir, fname)
                shutil.copy2(src_file, dest_file)
                copied_count += 1
    print(f"成功複製了 {copied_count} 張投影片圖檔至 poc_assets/。")
    
    # 3. 讀取 slides.json
    with open(slides_json_path, "r", encoding="utf-8") as f:
        slides_metadata = json.load(f)
        
    # 4. 解析日誌檔
    log_path = os.path.join(output_dir, "logs", "extractor.log")
    mae_points, log_events = parse_log_file(log_path)
    print(f"已從日誌中解析出 {len(mae_points)} 個 MAE 點與 {len(log_events)} 筆日誌事件。")
    
    # 5. 合成完整靜態展示資料 (poc_data.js)
    poc_payload = {
        "video_path": slides_metadata.get("video_path", "demo.mp4"),
        "title": slides_metadata.get("title", "demo.mp4"),
        "duration_sec": slides_metadata.get("duration_sec", 21.0),
        "duration_str": slides_metadata.get("duration_str", "00:00:21"),
        "fps": slides_metadata.get("fps", 10.0),
        "width": slides_metadata.get("width", 640),
        "height": slides_metadata.get("height", 360),
        "project_spirit": slides_metadata.get("project_spirit", {}),
        "slides": slides_metadata.get("slides", []),
        "mae_points": mae_points if mae_points else [{"sec": 0, "mae": 0.1}],
        "log_events": log_events
    }
    
    js_content = f"// 這是由實際執行結果產生的靜態 POC 展示素材數據包\nconst pocData = {json.dumps(poc_payload, indent=2, ensure_ascii=False)};\n"
    
    js_dest_path = os.path.join(target_poc_dir, "poc_data.js")
    with open(js_dest_path, "w", encoding="utf-8") as f:
        f.write(js_content)
    print(f"已生成靜態數據包檔案: {js_dest_path}")
    
    return True

if __name__ == "__main__":
    # 預設尋找 output/ 底下最新建立的任務資料夾進行導出
    parent_dir = "output"
    target_dir = "github-demo"
    
    if os.path.exists(parent_dir):
        subdirs = [
            os.path.join(parent_dir, d) 
            for d in os.listdir(parent_dir) 
            if d.startswith("task_") and os.path.exists(os.path.join(parent_dir, d, "slides.json"))
        ]
        if subdirs:
            # 取最新的一個
            latest_dir = max(subdirs, key=os.path.getmtime)
            success = export_workspace_to_poc(latest_dir, target_dir)
            if success:
                print("靜態素材包導出成功！可以配合 github-demo/index.html 進行靜態重播展示。")
        else:
            print("找不到任何 task_ 開頭的子目錄，請先執行網頁分析。")
    else:
        print("工作區目前無 output 目錄。")
