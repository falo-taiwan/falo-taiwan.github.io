import cv2
import numpy as np

def create_slide_frame(
    text: str, 
    bg_color: tuple, 
    size: tuple = (640, 360), 
    has_presenter: bool = False, 
    presenter_tick: int = 0
) -> np.ndarray:
    """
    建立一個模擬投影片的影格。
    畫面上包含一個白色的投影片主框 (20, 20) 到 (500, 340)，
    以及右側的講師視訊小框 (520, 220) 到 (620, 320)。
    """
    # 建立畫布
    frame = np.zeros((size[1], size[0], 3), dtype=np.uint8)
    
    # 整個畫面填滿背景底色 (例如暗色，模擬播放器)
    frame[:] = (30, 30, 30)
    
    # 繪製主投影片區域 (白色底色)
    cv2.rectangle(frame, (20, 20), (500, 340), bg_color, -1)
    # 投影片邊框
    cv2.rectangle(frame, (20, 20), (500, 340), (255, 255, 255), 2)
    
    # 寫入投影片內文字
    cv2.putText(frame, text, (40, 180), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2, cv2.LINE_AA)
    
    # 繪製講師視訊區域
    if has_presenter:
        # 視訊背景 (灰色)
        cv2.rectangle(frame, (520, 220), (620, 320), (80, 80, 80), -1)
        cv2.rectangle(frame, (520, 220), (620, 320), (150, 150, 150), 1)
        cv2.putText(frame, "Host", (545, 245), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)
        
        # 繪製一個移動的紅色方塊，模擬講者講話或肢體動作 (每影格移動)
        offset = int((presenter_tick % 10) * 4)  # 循環移動
        px = 540 + offset
        py = 270 + int(offset / 2)
        cv2.rectangle(frame, (px, py), (px + 15, py + 15), (0, 0, 255), -1)
        
    return frame

def generate_video(filename: str = "demo.mp4"):
    print(f"正在生成合成測試影片: {filename} ...")
    
    # 設定影片屬性
    width, height = 640, 360
    fps = 10
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(filename, fourcc, fps, (width, height))
    
    # 定義投影片配色 (BGR)
    blue_bg = (180, 80, 50)     # 投影片 1 (藍)
    green_bg = (50, 150, 50)    # 投影片 2 (綠)
    red_bg = (50, 50, 180)      # 投影片 3 (紅)
    
    # 1. Slide 1 (持續 4 秒)
    for i in range(40):
        frame = create_slide_frame("Slide 1: Intro to AI Agents", blue_bg)
        out.write(frame)
        
    # 2. Transition 1: 漸變至黑畫面 (持續 1 秒)
    slide1_frame = create_slide_frame("Slide 1: Intro to AI Agents", blue_bg)
    for i in range(10):
        alpha = 1.0 - (i / 10.0)
        black_transition = (slide1_frame * alpha).astype(np.uint8)
        out.write(black_transition)
        
    # 3. Slide 2: 包含右側講師視訊移動畫面 (持續 4 秒)
    # 這邊有講師視訊移動，因此若不裁切，畫面會因為紅色小方塊移動而偵測為不穩定；
    # 若啟用 Auto-crop 裁切掉右側，則投影片區域本身是完全靜止的，可快速達到穩定。
    for i in range(40):
        frame = create_slide_frame("Slide 2: Workflow Design", green_bg, has_presenter=True, presenter_tick=i)
        out.write(frame)
        
    # 4. Transition 2: 模糊過場 (持續 1 秒)
    slide2_frame = create_slide_frame("Slide 2: Workflow Design", green_bg, has_presenter=True, presenter_tick=40)
    for i in range(10):
        # 模糊程度隨時間遞增，最大 ksize 達 31
        ksize = (i * 3) | 1  # 確保是正奇數
        blur_frame = cv2.GaussianBlur(slide2_frame, (ksize, ksize), 0)
        out.write(blur_frame)
        
    # 5. Slide 3 (持續 4 秒)
    for i in range(40):
        frame = create_slide_frame("Slide 3: Conclusion & QA", red_bg)
        out.write(frame)
        
    # 6. Transition 3: 全白單色過場頁 (持續 1 秒)
    white_frame = np.ones((height, width, 3), dtype=np.uint8) * 240
    for i in range(10):
        out.write(white_frame)
        
    # 7. Slide 4: 重複 Slide 1 (持續 4 秒，測試重複頁排重)
    for i in range(40):
        frame = create_slide_frame("Slide 1: Intro to AI Agents", blue_bg)
        out.write(frame)
        
    # 8. 結尾黑畫面 (持續 2 秒)
    black_frame = np.zeros((height, width, 3), dtype=np.uint8)
    for i in range(20):
        out.write(black_frame)
        
    out.release()
    print("測試影片生成完成！")

if __name__ == "__main__":
    generate_video()
