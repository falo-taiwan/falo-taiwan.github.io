import os
import cv2
import pandas as pd
import numpy as np
from typing import Dict, Any, List, Optional, Tuple

from utils import dhash, hamming_distance, format_timestamp, setup_logger
from detector import compare_frames, is_blurry, is_black_screen, is_solid_screen, determine_auto_crop

class ExtractorState:
    DETECTING_TRANSITION = "DETECTING_TRANSITION"
    STABILIZING = "STABILIZING"

class VideoSlideExtractor:
    def __init__(self, config: Dict[str, Any]):
        """
        初始化 VideoSlideExtractor。
        
        Args:
            config: 設定字典，包含影片路徑、輸出路徑與所有閾值參數。
        """
        self.config = config
        self.video_path = config["video_path"]
        self.output_dir = config.get("output_dir", "output")
        self.frame_interval = float(config.get("frame_interval", 0.5))
        self.crop_mode = config.get("crop_mode", "full")
        self.lowres_height = config.get("lowres_height", "360")
        self.delete_video_after_done = bool(config.get("delete_video_after_done", False))
        
        # 設定檔自訂閾值或使用預設值
        self.t_mae_thresh = float(config.get("transition_mae_threshold", 8.0))
        self.t_corr_thresh = float(config.get("transition_hist_corr_threshold", 0.95))
        self.s_mae_thresh = float(config.get("stable_mae_threshold", 1.5))
        self.s_corr_thresh = float(config.get("stable_hist_corr_threshold", 0.99))
        
        self.stability_duration = float(config.get("stability_duration", 0.8))
        self.stability_timeout = float(config.get("stability_timeout", 5.0))
        
        self.blur_thresh = float(config.get("blur_threshold", 100.0))
        self.black_thresh = float(config.get("black_threshold", 15.0))
        self.solid_thresh = float(config.get("solid_threshold", 5.0))
        self.duplicate_thresh = int(config.get("duplicate_threshold", 4))
        
        # 建立輸出目錄結構
        self.slides_dir = os.path.join(self.output_dir, "slides")
        os.makedirs(self.slides_dir, exist_ok=True)
        
        # 初始化日誌
        self.logger = setup_logger(self.output_dir)
        
        # 線程中斷控制與 YouTube 標記
        self.stop_requested = False
        self.is_youtube = ("youtube.com" in self.video_path or "youtu.be" in self.video_path or self.video_path.startswith("http"))
        
        # 裁切區域 (x, y, w, h)
        self.crop_rect: Optional[Tuple[int, int, int, int]] = None
        raw_crop = config.get("crop_rect")
        if raw_crop:
            self.crop_rect = self._parse_crop_rect(raw_crop)
        self.original_crop_rect = self.crop_rect
            
        # VideoCapture 實例
        self.cap = None

    def _parse_crop_rect(self, crop_rect_val: Any) -> Optional[Tuple[int, int, int, int]]:
        """
        解析手動輸入的裁切框。支援像素 "x,y,w,h" 或百分比 "x%,y%,w%,h%" 或 [x, y, w, h] 陣列。
        """
        try:
            if isinstance(crop_rect_val, str):
                parts = [p.strip() for p in crop_rect_val.split(',')]
            elif isinstance(crop_rect_val, (list, tuple)):
                parts = [str(p) for p in crop_rect_val]
            else:
                return None
                
            if len(parts) != 4:
                self.logger.warning(f"裁切框設定值無效（必須為 4 個數值）: {crop_rect_val}")
                return None
                
            # 檢查是否為百分比格式
            is_percent = False
            parsed_parts = []
            for p in parts:
                if p.endswith('%'):
                    is_percent = True
                    parsed_parts.append(float(p[:-1]) / 100.0)
                else:
                    parsed_parts.append(float(p))
                    
            # 若為百分比，先暫存比例值，待開啟影片讀取解析度後再轉換為像素值
            if is_percent or any(0.0 < val <= 1.0 for val in parsed_parts):
                # 確保數值都在 0~1 之間
                if all(0.0 <= val <= 1.0 for val in parsed_parts):
                    return ("pct", parsed_parts[0], parsed_parts[1], parsed_parts[2], parsed_parts[3])
                else:
                    self.logger.warning(f"百分比或比例裁切值無效 (需在 0~1 之間): {crop_rect_val}")
                    return None
            else:
                # 絕對像素值
                return (int(parsed_parts[0]), int(parsed_parts[1]), int(parsed_parts[2]), int(parsed_parts[3]))
        except Exception as e:
            self.logger.error(f"解析裁切框參數出錯: {e}")
            return None

    def _apply_crop(self, frame: np.ndarray) -> np.ndarray:
        """
        將裁切框套用至當前影格。
        """
        if self.crop_rect is None:
            return frame
            
        h, w = frame.shape[:2]
        
        # 處理延遲解析的百分比裁切
        if len(self.crop_rect) == 5 and self.crop_rect[0] == "pct":
            _, px, py, pw, ph = self.crop_rect
            cx = max(0, int(px * w))
            cy = max(0, int(py * h))
            cw = min(w - cx, int(pw * w))
            ch = min(h - cy, int(ph * h))
            # 覆寫為具體像素，避免每次重複計算
            self.crop_rect = (cx, cy, cw, ch)
            self.logger.info(f"百分比裁切解析為實際像素: x={cx}, y={cy}, w={cw}, h={ch}")
            
        cx, cy, cw, ch = self.crop_rect
        # 邊界防呆限制
        cx = max(0, min(cx, w - 1))
        cy = max(0, min(cy, h - 1))
        cw = max(1, min(cw, w - cx))
        ch = max(1, min(ch, h - cy))
        
        return frame[cy:cy+ch, cx:cx+cw]

    def _apply_crop_original(self, frame: np.ndarray) -> np.ndarray:
        """
        將原始未縮放的裁切框套用至高清/原尺寸影格。
        """
        rect = getattr(self, "original_crop_rect", None)
        if rect is None:
            return frame
            
        h, w = frame.shape[:2]
        
        if len(rect) == 5 and rect[0] == "pct":
            _, px, py, pw, ph = rect
            cx = max(0, int(px * w))
            cy = max(0, int(py * h))
            cw = min(w - cx, int(pw * w))
            ch = min(h - cy, int(ph * h))
        else:
            cx, cy, cw, ch = rect
            
        # 邊界防呆
        cx = max(0, min(cx, w - 1))
        cy = max(0, min(cy, h - 1))
        cw = max(1, min(cw, w - cx))
        ch = max(1, min(ch, h - cy))
        
        return frame[cy:cy+ch, cx:cx+cw]

    def _download_youtube_video(self, url: str) -> Optional[str]:
        """
        使用 yt-dlp 將 YouTube 影片（已錄影或直播）下載為低解析度的本地暫存檔案。
        """
        self.logger.info("正在準備環境 (加載預編譯 ffmpeg)...")
        try:
            import imageio_ffmpeg
            import yt_dlp
        except ImportError as e:
            self.logger.error(f"缺少必要相依套件: {e}。請執行: pip install yt-dlp imageio-ffmpeg")
            return None

        # 設定 ffmpeg PATH 環境變數以解碼 HLS 直播串流
        try:
            ffmpeg_exe = imageio_ffmpeg.get_ffmpeg_exe()
            ffmpeg_dir = os.path.dirname(ffmpeg_exe)
            ffmpeg_link = os.path.join(ffmpeg_dir, 'ffmpeg')
            if not os.path.exists(ffmpeg_link):
                try:
                    os.symlink(ffmpeg_exe, ffmpeg_link)
                except Exception:
                    import shutil
                    shutil.copy(ffmpeg_exe, ffmpeg_link)
                    os.chmod(ffmpeg_link, 0o755)
            
            if ffmpeg_dir not in os.environ['PATH']:
                os.environ['PATH'] += os.pathsep + ffmpeg_dir
        except Exception as e:
            self.logger.warning(f"加載預編譯 ffmpeg 失敗: {e}，這可能會影響直播格式的下載。")

        # 決定低解析度下載限制
        height_limit = 360
        if self.lowres_height and str(self.lowres_height).isdigit():
            height_limit = int(self.lowres_height)
        elif self.lowres_height == 'original':
            height_limit = 99999
            
        format_str = f'best[height<={height_limit}]/worst'
        if height_limit >= 99999:
            format_str = 'best'
            
        self.logger.info(f"正在解析並下載 YouTube 暫存影片 (限定畫質 <= {height_limit}p 以加快速度)...")
        
        # 暫存檔路徑樣板 (將由 yt-dlp 自動加上副檔名，如 .mp4 或 .ts)
        temp_template = os.path.join(self.output_dir, 'yt_temp.%(ext)s')
        
        ydl_opts = {
            'format': format_str,
            'outtmpl': temp_template,
            'hls_prefer_native': True, 
            'external_downloader': 'native',
            'extractor_args': {
                'youtube': {
                    'player_client': ['android', 'mweb']
                }
            },
            'quiet': True,
            'no_warnings': True
        }

        try:
            # 1. 提取影片資訊判斷是否為直播
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=False)
                is_live = info.get('is_live', False) or info.get('live_status') == 'is_live'
                title = info.get('title', '無標題')
                self.logger.info(f"影片標題: {title} (直播中: {is_live})")
                
                if is_live:
                    # 如果是直播影片，開啟下載限制防止無限掛起
                    # 我們使用背景執行緒下載，並限制下載最長 15 秒（可抓取最近的直播片段）
                    self.logger.info("偵測為即時直播流，啟動限制性下載（拉取最近的片段並在 15 秒後中斷）...")
                    
                    import threading
                    
                    def run_download():
                        try:
                            res_info = ydl.extract_info(url, download=True)
                        except Exception:
                            # 忽略因超時中斷造成的拋出錯誤
                            pass
                            
                    dl_thread = threading.Thread(target=run_download)
                    dl_thread.daemon = True
                    dl_thread.start()
                    
                    # 限制下載 15 秒
                    dl_thread.join(timeout=15.0)
                    
                    # 搜尋已下載的暫存檔
                    resolved_file = None
                    self.logger.info(f"正在搜尋下載的直播暫存檔，輸出目錄檔案列表: {os.listdir(self.output_dir)}")
                    
                    # 先找正式合併檔，再找 HLS 下載中的 .part 暫存分片檔 (OpenCV 均能支援讀取)
                    for ext in ['mp4', 'ts', 'webm', 'mp4.part', 'ts.part', 'webm.part']:
                        test_file = os.path.join(self.output_dir, f'yt_temp.{ext}')
                        exists = os.path.exists(test_file)
                        size = os.path.getsize(test_file) if exists else 0
                        self.logger.info(f"檢查暫存路徑: {test_file} | 存在: {exists} | 大小: {size} 字节")
                        if exists and size > 10 * 1024:  # 降低限制到 10KB，確保短小片段也能被正常讀取
                            resolved_file = test_file
                            break
                            
                    if resolved_file:
                        self.logger.info(f"直播暫存影片擷取成功，檔案路徑: {resolved_file}")
                        return resolved_file
                    else:
                        self.logger.error("直播暫存影片下載失敗，未找到有效檔案。")
                        return None
                else:
                    # 一般錄製好的影片，直接全量下載 (因為 360p 速度極快)
                    self.logger.info("正在下載完整錄影存檔...")
                    res_info = ydl.extract_info(url, download=True)
                    resolved_file = ydl.prepare_filename(res_info)
                    self.logger.info(f"影片下載成功，本地暫存路徑: {resolved_file}")
                    return resolved_file
        except Exception as e:
            self.logger.error(f"下載 YouTube 影片出錯: {e}")
            return None

    def run(self):
        """
        執行影片投影片萃取流程。
        """
        self.logger.info("=========================================")
        self.logger.info(f"開始執行 Video Slide Extractor")
        self.logger.info(f"輸入影片: {self.video_path}")
        self.logger.info(f"輸出目錄: {self.output_dir}")
        self.logger.info(f"抽幀間隔: {self.frame_interval} 秒")
        self.logger.info(f"裁切模式: {self.crop_mode}")
        
        # 判斷是否為 YouTube 串流
        open_path = self.video_path
        if self.is_youtube:
            downloaded_file = self._download_youtube_video(self.video_path)
            if downloaded_file:
                open_path = downloaded_file
            else:
                self.logger.error("無法下載 YouTube 影片，退出擷取流程。")
                return
                
        cap = cv2.VideoCapture(open_path)
        self.cap = cap
        if not cap.isOpened():
            self.logger.error(f"無法打開影片或網路串流: {self.video_path}")
            return
            
        # 取得影片基本資訊
        fps = cap.get(cv2.CAP_PROP_FPS)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        self.cap_w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.cap_h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        
        # 低清解析度計算與縮放比例
        self.lowres_w = self.cap_w
        self.lowres_h = self.cap_h
        self.scale_factor = 1.0
        
        # 解析 lowres_height
        target_h = None
        if self.lowres_height and str(self.lowres_height).isdigit():
            target_h = int(self.lowres_height)
            
        if target_h and target_h < self.cap_h:
            self.scale_factor = target_h / self.cap_h
            self.lowres_h = target_h
            self.lowres_w = int(self.cap_w * self.scale_factor)
            self.logger.info(f"啟用極速低解析度分析模式：原解析度 {self.cap_w}x{self.cap_h} -> 縮放為 {self.lowres_w}x{self.lowres_h} (比例: {self.scale_factor:.4f})")
        else:
            self.logger.info(f"無須縮放或解析度設定為原始畫質：使用解析度 {self.cap_w}x{self.cap_h}")
            
        # 若啟用縮放且裁切框為絕對像素，需將裁切框等比例縮小以對齊低解析度影格
        if self.scale_factor < 1.0 and self.crop_rect is not None:
            if len(self.crop_rect) == 4:  # 絕對像素 (x, y, w, h)
                cx, cy, cw, ch = self.crop_rect
                cx_scaled = int(cx * self.scale_factor)
                cy_scaled = int(cy * self.scale_factor)
                cw_scaled = max(1, int(cw * self.scale_factor))
                ch_scaled = max(1, int(ch * self.scale_factor))
                self.crop_rect = (cx_scaled, cy_scaled, cw_scaled, ch_scaled)
                self.logger.info(f"已等比例縮小絕對像素裁切框：原 {cx},{cy},{cw},{ch} -> 縮小為 {self.crop_rect}")
                
        frame_w = self.lowres_w
        frame_h = self.lowres_h
        
        # 強健性處理：防範 FPS 獲取失敗或長度未知 (如 YouTube 串流)
        if fps <= 0:
            fps = 25.0
            self.logger.warning("讀取影片 FPS 失敗，預設採用 25.0 FPS")
            
        if total_frames > 0:
            duration_sec = total_frames / fps
            duration_str = format_timestamp(duration_sec)
        else:
            duration_sec = -1
            duration_str = "未知長度/即時串流"
            
        self.logger.info(f"影片解析度: {frame_w}x{frame_h} | FPS: {fps:.2f} | 總長度: {duration_str}")
        
        # 決定裁切區域
        if self.crop_mode == "auto":
            self.logger.info("正在分析影片以自動偵測投影片範圍...")
            auto_box = determine_auto_crop(open_path, samples_count=15, logger=self.logger)
            if auto_box:
                self.original_crop_rect = auto_box
                if self.scale_factor < 1.0:
                    cx, cy, cw, ch = auto_box
                    self.crop_rect = (
                        int(cx * self.scale_factor),
                        int(cy * self.scale_factor),
                        max(1, int(cw * self.scale_factor)),
                        max(1, int(ch * self.scale_factor))
                    )
                    self.logger.info(f"已啟用 Auto-crop 並等比例縮小：原 {auto_box} -> 縮小為 {self.crop_rect}")
                else:
                    self.crop_rect = auto_box
                    self.logger.info(f"已啟用 Auto-crop，裁切區域: {self.crop_rect}")
            else:
                self.original_crop_rect = None
                self.crop_rect = None
                self.logger.info("未偵測到穩定的投影片矩形，將使用 Full-frame (不裁切)。")
        elif self.crop_mode == "manual":
            if self.crop_rect:
                self.logger.info(f"已啟用手動裁切，設定為: {self.crop_rect}")
            else:
                self.logger.warning("設定為手動裁切但未提供有效 crop_rect，將使用 Full-frame (不裁切)。")
        else:
            self.crop_rect = None
            self.logger.info("使用 Full-frame 模式。")

        # 狀態機變數初始化
        state = ExtractorState.DETECTING_TRANSITION
        
        # 參考影像（前一張已儲存的投影片，裁切後）
        ref_slide_cropped: Optional[np.ndarray] = None
        ref_slide_hash: Optional[int] = None
        
        # 穩定過程中的候選影像及狀態（裁切後）
        stable_candidate_cropped: Optional[np.ndarray] = None
        stable_candidate_full: Optional[np.ndarray] = None  # 最終要儲存的投影片
        stable_candidate_time: float = 0.0
        last_stability_frame_cropped: Optional[np.ndarray] = None
        stability_accumulated_time: float = 0.0
        transition_trigger_time: float = 0.0
        
        saved_slides: List[Dict[str, Any]] = []
        
        # 計算跳幀步長
        frame_step = int(max(1, round(fps * self.frame_interval)))
        
        current_frame_idx = 0
        
        while True:
            # 檢查前端/後端中斷請求
            if getattr(self, "stop_requested", False):
                self.logger.info("檢測到使用者停止指令，終止擷取影片流程。")
                break
                
            # 讀取當前幀
            ret, frame = cap.read()
            if not ret or frame is None:
                break
                
            original_frame = frame.copy()
                
            # 若啟用極速分析，則將影格縮小至低解析度以加快後續運算速度
            if self.scale_factor < 1.0:
                frame = cv2.resize(frame, (self.lowres_w, self.lowres_h))
                
            current_sec = cap.get(cv2.CAP_PROP_POS_MSEC) / 1000.0
            # 防呆：若 OPenCV POS_MSEC 返回 0 或無效，改以影格數計算時間
            if current_sec <= 0.0 and current_frame_idx > 0:
                current_sec = current_frame_idx / fps
                
            # 套用裁切
            cropped_frame = self._apply_crop(frame)
            
            # 儲存即時進度預覽影格 (供 HTML 介面即時渲染)
            if cropped_frame is not None and cropped_frame.size > 0:
                preview_path = os.path.join(self.output_dir, "preview_frame.jpg")
                cv2.imwrite(preview_path, cropped_frame)
            
            # --- 狀態機邏輯開始 ---
            if state == ExtractorState.DETECTING_TRANSITION:
                if ref_slide_cropped is None:
                    # 初始狀態：尋找第一張投影片
                    # 排除黑底與模糊
                    is_black, _ = is_black_screen(cropped_frame, self.black_thresh)
                    is_blur, _ = is_blurry(cropped_frame, self.blur_thresh)
                    
                    if not is_black and not is_blur:
                        # 進入穩定化流程，確認第一張投影片本身是否穩定
                        state = ExtractorState.STABILIZING
                        transition_trigger_time = current_sec
                        stable_candidate_cropped = cropped_frame.copy()
                        stable_candidate_full = original_frame.copy()
                        stable_candidate_time = current_sec
                        last_stability_frame_cropped = cropped_frame.copy()
                        stability_accumulated_time = 0.0
                        self.logger.info(f"偵測到影片開頭有效畫面於 {format_timestamp(current_sec)}，開始確認穩定度...")
                else:
                    # 比對當前幀與 reference_slide 的差異
                    mae, hist_corr = compare_frames(cropped_frame, ref_slide_cropped)
                    
                    # 觸發換頁條件：MAE 變大，或者直方圖相關性降低
                    if mae > self.t_mae_thresh or hist_corr < self.t_corr_thresh:
                        state = ExtractorState.STABILIZING
                        transition_trigger_time = current_sec
                        stable_candidate_cropped = cropped_frame.copy()
                        stable_candidate_full = original_frame.copy()
                        stable_candidate_time = current_sec
                        last_stability_frame_cropped = cropped_frame.copy()
                        stability_accumulated_time = 0.0
                        self.logger.info(f"偵測到換頁觸發於 {format_timestamp(current_sec)} (MAE: {mae:.2f}, Corr: {hist_corr:.3f})，進入穩定化追蹤...")
                        
            elif state == ExtractorState.STABILIZING:
                # 比較當前幀與「上一幀」的連續變化，看是否已經靜止（穩定）
                mae_consec, corr_consec = compare_frames(cropped_frame, last_stability_frame_cropped)
                
                # 是否非常穩定（無變動）
                is_stable = (mae_consec < self.s_mae_thresh) and (corr_consec > self.s_corr_thresh)
                
                if is_stable:
                    stability_accumulated_time += self.frame_interval
                else:
                    # 畫面仍在變動中，重置穩定累積時間，並更新候選影像
                    stability_accumulated_time = 0.0
                    stable_candidate_cropped = cropped_frame.copy()
                    stable_candidate_full = original_frame.copy()
                    stable_candidate_time = current_sec
                    
                last_stability_frame_cropped = cropped_frame.copy()
                
                # 檢查超時或已達穩定時間
                reached_stability = (stability_accumulated_time >= self.stability_duration)
                reached_timeout = (current_sec - transition_trigger_time >= self.stability_timeout)
                
                if reached_stability or reached_timeout:
                    if reached_timeout and not reached_stability:
                        self.logger.info(f"畫面穩定超時 ({self.stability_timeout}s)，強行對當前畫面進行品質與重複判定。")
                        
                    # 進行品質與重複判定
                    is_black, black_val = is_black_screen(stable_candidate_cropped, self.black_thresh)
                    is_blur, blur_val = is_blurry(stable_candidate_cropped, self.blur_thresh)
                    is_solid, solid_val = is_solid_screen(stable_candidate_cropped, self.solid_thresh)
                    
                    if is_black or is_blur or is_solid:
                        self.logger.info(
                            f"拋棄不合格候選影格於 {format_timestamp(stable_candidate_time)} "
                            f"(黑底: {is_black}(亮度 {black_val:.1f}), 模糊: {is_blur}(變異數 {blur_val:.1f}), 單色: {is_solid}(標準差 {solid_val:.1f}))"
                        )
                        # 重設狀態機回到偵測模式，此時仍保留舊的 ref_slide
                        state = ExtractorState.DETECTING_TRANSITION
                    else:
                        # 品質通過，計算 dHash 與平均顏色進行防重排重
                        candidate_hash = dhash(stable_candidate_cropped)
                        candidate_mean = cv2.mean(stable_candidate_cropped)[:3]
                        
                        # 與過去所有存檔比對
                        is_duplicate = False
                        dup_slide_no = -1
                        for prev in saved_slides:
                            dist = hamming_distance(candidate_hash, prev["dhash"])
                            # 計算平均 BGR 歐氏距離
                            c_dist = float(np.linalg.norm(np.array(candidate_mean) - np.array(prev["mean_color"])))
                            
                            # 當結構相似且顏色相近時才判定為重複頁
                            if dist <= self.duplicate_thresh and c_dist <= 15.0:
                                is_duplicate = True
                                dup_slide_no = prev["slide_no"]
                                break
                                
                        if is_duplicate:
                            self.logger.info(
                                f"偵測到重複畫面於 {format_timestamp(stable_candidate_time)} "
                                f"(與 slide_{dup_slide_no:03d}.png 相似，漢明距離 <= {self.duplicate_thresh})，跳過存檔。"
                            )
                            # **重要**：即便跳過存檔，也必須更新 ref_slide 為當前畫面，以便後續順利探測下一次換頁
                            ref_slide_cropped = stable_candidate_cropped.copy()
                            ref_slide_hash = candidate_hash
                            state = ExtractorState.DETECTING_TRANSITION
                        else:
                            # 儲存投影片
                            slide_no = len(saved_slides) + 1
                            filename = f"slide_{slide_no:03d}.png"
                            filepath = os.path.join(self.slides_dir, filename)
                            
                            # 裁切並儲存 (改用原始大圖裁切，儲存時不縮小不拉伸)
                            final_save_img = self._apply_crop_original(stable_candidate_full)
                            cv2.imwrite(filepath, final_save_img)
                            
                            # 註冊紀錄 (含 blur_value)
                            timestamp_str = format_timestamp(stable_candidate_time)
                            saved_slides.append({
                                "slide_no": slide_no,
                                "filename": filename,
                                "timestamp": timestamp_str,
                                "seconds": stable_candidate_time,
                                "dhash": candidate_hash,
                                "mean_color": candidate_mean,
                                "blur_value": blur_val
                            })
                            
                            self.logger.info(
                                f"儲存投影片: {filename} | 時間點: {timestamp_str} "
                                f"(模糊值: {blur_val:.1f}, 雜湊: {candidate_hash:016x})"
                            )
                            
                            ref_slide_cropped = stable_candidate_cropped.copy()
                            ref_slide_hash = candidate_hash
                            state = ExtractorState.DETECTING_TRANSITION
            # --- 狀態機邏輯結束 ---
            
            # 跳過接下來的 frame_step - 1 幀
            for _ in range(frame_step - 1):
                cap.grab()
                current_frame_idx += 1
                
            current_frame_idx += 1
            
        cap.release()
        
        # 寫出 slides.json
        import json
        slides_json_path = os.path.join(self.output_dir, "slides.json")
        
        slides_data = []
        for s in saved_slides:
            slides_data.append({
                "slide_no": s["slide_no"],
                "filename": s["filename"],
                "timestamp": s["timestamp"],
                "seconds": float(s["seconds"]),
                "dhash": f"{s['dhash']:016x}" if isinstance(s['dhash'], int) else str(s['dhash']),
                "mean_color": [float(x) for x in s["mean_color"][:3]] if isinstance(s["mean_color"], (list, tuple, np.ndarray)) else [0.0, 0.0, 0.0],
                "blur_value": float(s.get("blur_value", 0.0)),
                "has_enhanced": False
            })
            
        project_spirit = {
            "core_philosophy": "捕捉專家經驗 --> 建立 KM (知識管理) 資料庫",
            "features": [
                "自動化影格變動分析，精準捕捉投影片換頁畫面",
                "執行時完全不耗費任何 AI API Token，省電且無執行成本",
                "融合電腦視覺演算法（MAE 換頁判定、dHash 結構去重、Laplacian 模糊過濾）",
                "採用 Human-in-the-Loop (人類最終確認) 互動機制，配合拉桿滑塊即時比對影像強化效果，才輸出最終 PDF/HTML"
            ],
            "workflow": [
                "影片分析",
                "畫面變化偵測",
                "換頁推測",
                "相似度分析",
                "模糊檢測",
                "重複頁排除",
                "候選投影片"
            ],
            "development_note": "開發時期善用 AI 輔助提效，執行運作時則仰賴純粹的 OpenCV 高效電腦視覺演算法，兼具高開發速度與零運作成本。"
        }
            
        metadata = {
            "title": os.path.basename(self.video_path),
            "video_path": self.video_path,
            "duration_sec": float(duration_sec),
            "duration_str": duration_str,
            "fps": float(fps),
            "width": int(self.cap_w),
            "height": int(self.cap_h),
            "crop_mode": self.crop_mode,
            "crop_rect": self.original_crop_rect,
            "project_spirit": project_spirit,
            "slides": slides_data
        }
        
        try:
            with open(slides_json_path, "w", encoding="utf-8") as f:
                json.dump(metadata, f, indent=2, ensure_ascii=False)
            self.logger.info(f"已產出 JSON 資訊檔: {slides_json_path} (共 {len(slides_data)} 張投影片)")
        except Exception as e:
            self.logger.error(f"寫入 JSON 資訊檔失敗: {e}")
            
        # 清理可能殘留的 YouTube 暫存檔案 (包含下載產生的 .part 暫存檔)
        if self.is_youtube and self.delete_video_after_done:
            self.logger.info("正在清理 YouTube 暫存影片檔案...")
            for f in os.listdir(self.output_dir):
                if f.startswith("yt_temp"):
                    try:
                        os.remove(os.path.join(self.output_dir, f))
                    except Exception:
                        pass

        self.logger.info("Video Slide Extractor 執行完畢。")
        self.logger.info("=========================================")

def enhance_image(img_path: str, enhance_type: str) -> np.ndarray:
    """
    影像強化函數：支援 sharpen (銳化), clahe (對比), denoise (降噪), document (二值化文檔)
    """
    import cv2
    import numpy as np
    
    img = cv2.imread(img_path)
    if img is None or img.size == 0:
        raise ValueError(f"無法讀取圖片: {img_path}")
        
    if enhance_type == "sharpen":
        # USM 銳化
        blurred = cv2.GaussianBlur(img, (5, 5), 1.5)
        enhanced = cv2.addWeighted(img, 1.5, blurred, -0.5, 0)
    elif enhance_type == "clahe":
        # CLAHE 自適應直方圖均衡化
        lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        cl = clahe.apply(l)
        limg = cv2.merge((cl, a, b))
        enhanced = cv2.cvtColor(limg, cv2.COLOR_LAB2BGR)
    elif enhance_type == "denoise":
        # 雙邊濾波去噪
        enhanced = cv2.bilateralFilter(img, 9, 75, 75)
    elif enhance_type == "document":
        # 高對比文檔模式
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        thresh = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                       cv2.THRESH_BINARY, 11, 2)
        enhanced = cv2.cvtColor(thresh, cv2.COLOR_GRAY2BGR)
    elif enhance_type == "superres_2x" or enhance_type == "superres_4x":
        # 智慧放大 2x/4x (Lanczos-4 內插 + USM 邊緣對比重建)
        scale = 2 if enhance_type == "superres_2x" else 4
        h, w = img.shape[:2]
        new_w = int(w * scale)
        new_h = int(h * scale)
        resized = cv2.resize(img, (new_w, new_h), interpolation=cv2.INTER_LANCZOS4)
        
        # 依放大倍率套用 USM 銳化，回復字體筆劃的微細邊緣對比
        ksize = (5, 5) if scale == 2 else (9, 9)
        blurred = cv2.GaussianBlur(resized, ksize, 1.5)
        enhanced = cv2.addWeighted(resized, 1.6, blurred, -0.6, 0)
    else:
        # 預設或不支援的類型直接回傳原圖
        enhanced = img.copy()
        
    return enhanced
