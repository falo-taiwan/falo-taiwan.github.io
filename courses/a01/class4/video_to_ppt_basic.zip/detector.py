import cv2
import numpy as np
from typing import Tuple, Optional, List

def compare_frames(img1: np.ndarray, img2: np.ndarray, size: Tuple[int, int] = (128, 128)) -> Tuple[float, float]:
    """
    比對兩張影像的差異，用於偵測投影片換頁。
    將影像縮小至 `size` 以濾除極小像素變動與雜訊，並提升運算效率。
    
    Args:
        img1, img2: BGR 格式的影像。
        size: 縮小比對的解析度。
        
    Returns:
        Tuple[float, float]: (MAE 像素平均絕對誤差, Histogram 灰階直方圖相關性)
        - MAE 越接近 0 代表影像越像。
        - Histogram 相關性介於 -1.0 到 1.0 之間，越接近 1.0 代表越像。
    """
    # 轉為灰階
    g1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
    g2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
    
    # 縮小解析度
    g1_resized = cv2.resize(g1, size, interpolation=cv2.INTER_AREA)
    g2_resized = cv2.resize(g2, size, interpolation=cv2.INTER_AREA)
    
    # 計算平均絕對誤差 (MAE)
    mae = float(np.mean(np.abs(g1_resized.astype(np.float32) - g2_resized.astype(np.float32))))
    
    # 計算灰階直方圖
    h1 = cv2.calcHist([g1_resized], [0], None, [64], [0, 256])
    h2 = cv2.calcHist([g2_resized], [0], None, [64], [0, 256])
    
    # 正規化直方圖
    cv2.normalize(h1, h1, 0, 1, cv2.NORM_MINMAX)
    cv2.normalize(h2, h2, 0, 1, cv2.NORM_MINMAX)
    
    # 直方圖相關性比較
    hist_corr = float(cv2.compareHist(h1, h2, cv2.HISTCMP_CORREL))
    
    return mae, hist_corr

def is_blurry(image: np.ndarray, threshold: float = 100.0) -> Tuple[bool, float]:
    """
    使用 Laplacian 變異數偵測影像是否模糊。
    變異數越低，代表邊緣越不銳利（模糊）。
    
    Args:
        image: BGR 影像。
        threshold: 模糊判定閾值，低於此值則視為模糊。
        
    Returns:
        Tuple[bool, float]: (是否模糊, 變異數值)
    """
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    var = float(cv2.Laplacian(gray, cv2.CV_64F).var())
    return (var < threshold), var

def is_black_screen(image: np.ndarray, threshold: float = 15.0) -> Tuple[bool, float]:
    """
    偵測是否為黑畫面。
    計算影像灰階平均值，低於閾值則視為黑畫面。
    
    Args:
        image: BGR 影像。
        threshold: 亮度閾值 (0-255)。
        
    Returns:
        Tuple[bool, float]: (是否為黑畫面, 平均亮度)
    """
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    mean_val = float(np.mean(gray))
    return (mean_val < threshold), mean_val

def is_solid_screen(image: np.ndarray, std_threshold: float = 5.0) -> Tuple[bool, float]:
    """
    偵測是否為單色畫面或無內容的純色頁面。
    計算影像像素標準差，低於閾值代表畫面幾乎為單一色彩（無對比與文字）。
    
    Args:
        image: BGR 影像。
        std_threshold: 標準差閾值。
        
    Returns:
        Tuple[bool, float]: (是否為單色畫面, 標準差)
    """
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    std_val = float(np.std(gray))
    return (std_val < std_threshold), std_val

def detect_slide_region(frame: np.ndarray, min_area_ratio: float = 0.25) -> Optional[Tuple[int, int, int, int]]:
    """
    偵測影像中最大的投影片（矩形）區域。
    適用於排除講師視訊頭與 Zoom/Meet 視窗白邊。
    
    Args:
        frame: BGR 影像。
        min_area_ratio: 最小面積比例（相對於整個畫面）。
        
    Returns:
        Optional[Tuple[int, int, int, int]]: (x, y, w, h) 裁切框，若未偵測到則返回 None。
    """
    h_frame, w_frame = frame.shape[:2]
    frame_area = h_frame * w_frame
    
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    
    # 使用 Canny 進行邊緣偵測
    edged = cv2.Canny(blurred, 30, 150)
    
    # 尋找外部輪廓
    contours, _ = cv2.findContours(edged, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    best_rect = None
    max_area = 0
    
    for c in contours:
        peri = cv2.arcLength(c, True)
        approx = cv2.approxPolyDP(c, 0.02 * peri, True)
        
        # 尋找具有 4 個頂點的凸多邊形（近似矩形）
        if len(approx) == 4 and cv2.isContourConvex(approx):
            x, y, w, h = cv2.boundingRect(approx)
            area = w * h
            
            # 過濾面積太小的區域
            if area > min_area_ratio * frame_area:
                aspect_ratio = float(w) / h
                # 投影片通常為 4:3 (~1.33) 或 16:9 (~1.77) 之間，容許值設定在 1.0 至 2.1
                if 1.0 <= aspect_ratio <= 2.1:
                    if area > max_area:
                        max_area = area
                        best_rect = (x, y, w, h)
                        
    return best_rect

def determine_auto_crop(video_path: str, samples_count: int = 15, logger = None) -> Optional[Tuple[int, int, int, int]]:
    """
    從影片中均勻抽樣數幀，自動計算一個最合適且一致的投影片裁切區域。
    
    Args:
        video_path: 影片檔案路徑。
        samples_count: 抽樣幀數。
        logger: 用於記錄資訊的 Logger。
        
    Returns:
        Optional[Tuple[int, int, int, int]]: 一致的 (x, y, w, h) 裁切框，若無法確定則返回 None (使用全畫面)。
    """
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        if logger:
            logger.error(f"無法打開影片進行 Auto-crop 分析: {video_path}")
        return None
        
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    frame_w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    if total_frames <= 0 or frame_w <= 0 or frame_h <= 0:
        cap.release()
        return None
        
    # 在影片的前 80% 部分均勻採樣，避免結尾黑畫面或花絮影響
    sample_indices = np.linspace(total_frames * 0.1, total_frames * 0.9, samples_count, dtype=int)
    detected_boxes = []
    
    for idx in sample_indices:
        cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
        ret, frame = cap.read()
        if not ret or frame is None:
            continue
            
        # 排除黑底或雜訊幀
        is_black, _ = is_black_screen(frame, 20.0)
        if is_black:
            continue
            
        box = detect_slide_region(frame)
        if box:
            detected_boxes.append(box)
            
    cap.release()
    
    if not detected_boxes:
        if logger:
            logger.info("Auto-crop: 未能在採樣幀中偵測到任何投影片邊界，將使用全畫面。")
        return None
        
    # 將相近的 Bounding Boxes 分群 (容許誤差 5%)
    # 我們以 center_x, center_y, w, h 為特徵值進行相近度檢驗
    tolerance_x = frame_w * 0.05
    tolerance_y = frame_h * 0.05
    
    clusters: List[List[Tuple[int, int, int, int]]] = []
    for box in detected_boxes:
        x, y, w, h = box
        matched = False
        for cluster in clusters:
            ref_x, ref_y, ref_w, ref_h = cluster[0]
            if (abs(x - ref_x) < tolerance_x and 
                abs(y - ref_y) < tolerance_y and 
                abs(w - ref_w) < tolerance_x and 
                abs(h - ref_h) < tolerance_y):
                cluster.append(box)
                matched = True
                break
        if not matched:
            clusters.append([box])
            
    # 找出樣本數最多的群類
    clusters.sort(key=len, reverse=True)
    best_cluster = clusters[0]
    
    # 必須有超過 30% 的有效樣本偵測到此區域才算一致
    if len(best_cluster) < (samples_count * 0.3):
        if logger:
            logger.info("Auto-crop: 偵測到的矩形區域不夠一致，將使用全畫面。")
        return None
        
    # 計算該群組的平均框
    avg_box = np.mean(best_cluster, axis=0).astype(int)
    ax, ay, aw, ah = avg_box[0], avg_box[1], avg_box[2], avg_box[3]
    
    # 防呆限制：確保不超出邊界
    ax = max(0, ax)
    ay = max(0, ay)
    aw = min(frame_w - ax, aw)
    ah = min(frame_h - ay, ah)
    
    # 如果偵測出的區域非常接近全螢幕 (例如面積佔 95% 以上，且原點靠近 0,0)
    # 就直接用全畫面，避免切到邊緣
    if aw * ah > 0.95 * (frame_w * frame_h):
        if logger:
            logger.info("Auto-crop: 偵測區域接近全螢幕，採用全螢幕模式。")
        return None
        
    if logger:
        logger.info(f"Auto-crop: 自動偵測到投影片區域 x={ax}, y={ay}, w={aw}, h={ah} (樣本佔比 {len(best_cluster)}/{len(detected_boxes)})")
        
    return int(ax), int(ay), int(aw), int(ah)
